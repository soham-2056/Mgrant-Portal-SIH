"use client";

import * as React from "react";
import AuthenticationFlow from "@/components/AuthenticationFlow";
import MigrantWorkerDashboard from "@/components/MigrantWorkerDashboard";
import HealthRecordsView from "@/components/HealthRecordsView";
import DoctorPortal from "@/components/DoctorPortal";
import GovernmentAdminDashboard from "@/components/GovernmentAdminDashboard";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { LayoutDashboard, ShieldCheck, Stethoscope, Users } from "lucide-react";

type Role = "worker" | "doctor" | "admin";

type AuthState =
  | { status: "unauthenticated" }
  | {
      status: "authenticated";
      role: Role;
      token: string;
      userId: string;
    };

export default function Page() {
  const [auth, setAuth] = React.useState<AuthState>({ status: "unauthenticated" });
  const [workerTab, setWorkerTab] = React.useState<"overview" | "records">("overview");

  function handleSignOut() {
    setAuth({ status: "unauthenticated" });
    setWorkerTab("overview");
  }

  const roleBadge =
    auth.status === "authenticated" ? (
      <Badge variant="secondary" className="capitalize">
        {auth.role === "worker" ? "Worker" : auth.role === "doctor" ? "Doctor" : "Admin"}
      </Badge>
    ) : null;

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="mx-auto max-w-screen-2xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="inline-flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                <LayoutDashboard className="h-5 w-5 text-primary" aria-hidden />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">Migrant Worker Health Portal</p>
                <p className="truncate text-xs text-muted-foreground">Role-based multi-portal app</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {roleBadge}
              {auth.status === "authenticated" ? (
                <>
                  <Badge variant="outline" className="hidden sm:inline-flex">
                    {auth.userId}
                  </Badge>
                  <Button variant="outline" size="sm" onClick={handleSignOut}>
                    Sign out
                  </Button>
                </>
              ) : null}
            </div>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-screen-2xl px-4 sm:px-6 lg:px-8 py-8 md:py-10">
        {auth.status === "unauthenticated" ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10 items-start">
            <div className="order-2 lg:order-1">
              <Card className="bg-card">
                <CardContent className="p-6 md:p-8">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="h-5 w-5 text-primary" />
                      <h1 className="text-xl sm:text-2xl font-semibold">Secure access for every role</h1>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Sign in once and get routed to your dedicated workspace. Migrant workers manage personal health and jobs, doctors manage patients, and government admins get analytics and oversight.
                    </p>
                    <div className="grid gap-3 sm:grid-cols-3">
                      <div className="rounded-md border p-3">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Users className="h-4 w-4 text-primary" />
                          Worker
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">QR health card, score, jobs, hospitals, records.</p>
                      </div>
                      <div className="rounded-md border p-3">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Stethoscope className="h-4 w-4 text-primary" />
                          Doctor
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">Scan QR, patient profiles, vitals, labs, follow-ups.</p>
                      </div>
                      <div className="rounded-md border p-3">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <ShieldCheck className="h-4 w-4 text-primary" />
                          Admin
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">Analytics, surveillance, compliance, exports.</p>
                      </div>
                    </div>
                    <Separator />
                    <p className="text-xs text-muted-foreground">
                      Demo tips: Use any credentials per instructions in the form. OTP demo code: 123456.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-start justify-center">
                <AuthenticationFlow
                  defaultRole="worker"
                  defaultMode="login"
                  onAuthSuccess={(p) =>
                    setAuth({
                      status: "authenticated",
                      role: p.role,
                      token: p.token,
                      userId: p.userId,
                    })
                  }
                />
              </div>
            </div>
          </div>
        ) : auth.role === "worker" ? (
          <div className="grid gap-4">
            <Tabs value={workerTab} onValueChange={(v) => setWorkerTab(v as typeof workerTab)} className="w-full">
              <TabsList className="w-full sm:w-auto">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="records">Health Records</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="mt-4">
                <MigrantWorkerDashboard />
              </TabsContent>
              <TabsContent value="records" className="mt-4">
                <HealthRecordsView />
              </TabsContent>
            </Tabs>
          </div>
        ) : auth.role === "doctor" ? (
          <DoctorPortal />
        ) : (
          <GovernmentAdminDashboard role="state" />
        )}
      </section>
    </main>
  );
}