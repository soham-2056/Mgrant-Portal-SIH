"use client";

import * as React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutDashboard,
  PanelLeft,
  PanelLeftClose,
  LayoutGrid,
  ScanQrCode,
  Hospital,
} from "lucide-react";
import QRCode from "qrcode";
import { toast } from "sonner";

import { cn } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";

type Language = "en" | "hi" | "bn" | "ta" | "ms";

const i18n: Record<
  Language,
  {
    dashboard: string;
    qrSection: string;
    generateQR: string;
    download: string;
    print: string;
    workerId: string;
    workerName: string;
    healthScore: string;
    overallHealth: string;
    riskLevel: string;
    parameters: string;
    records: string;
    viewDetails: string;
    jobRecs: string;
    filter: string;
    category: string;
    all: string;
    lightDuty: string;
    mediumDuty: string;
    heavyDuty: string;
    searchJobs: string;
    apply: string;
    saved: string;
    save: string;
    hospitalLocator: string;
    yourLocation: string;
    specialty: string;
    distance: string;
    sortBy: string;
    nearest: string;
    book: string;
    bookAppointment: string;
    date: string;
    time: string;
    notes: string;
    confirmBooking: string;
    cancel: string;
    language: string;
    moderate: string;
    high: string;
    low: string;
    suitability: string;
    recommended: string;
    notSuitable: string;
    details: string;
    loading: string;
  }
> = {
  en: {
    dashboard: "Migrant Worker Dashboard",
    qrSection: "QR Code",
    generateQR: "Generate",
    download: "Download",
    print: "Print",
    workerId: "Worker ID",
    workerName: "Worker Name",
    healthScore: "Health Score",
    overallHealth: "Overall Health",
    riskLevel: "Risk Level",
    parameters: "Parameters",
    records: "Health Records",
    viewDetails: "View details",
    jobRecs: "Job Recommendations",
    filter: "Filter",
    category: "Category",
    all: "All",
    lightDuty: "Light Duty",
    mediumDuty: "Medium Duty",
    heavyDuty: "Heavy Duty",
    searchJobs: "Search jobs...",
    apply: "Apply",
    saved: "Saved",
    save: "Save",
    hospitalLocator: "Nearby Hospital Locator",
    yourLocation: "Your location",
    specialty: "Specialty",
    distance: "Distance",
    sortBy: "Sort by",
    nearest: "Nearest",
    book: "Book",
    bookAppointment: "Book Appointment",
    date: "Date",
    time: "Time",
    notes: "Notes",
    confirmBooking: "Confirm booking",
    cancel: "Cancel",
    language: "Language",
    moderate: "Moderate",
    high: "High",
    low: "Low",
    suitability: "Suitability",
    recommended: "Recommended",
    notSuitable: "Not suitable",
    details: "Details",
    loading: "Loading...",
  },
  hi: {
    dashboard: "प्रवासी श्रमिक डैशबोर्ड",
    qrSection: "क्यूआर कोड",
    generateQR: "जेनरेट करें",
    download: "डाउनलोड",
    print: "प्रिंट",
    workerId: "श्रमिक आईडी",
    workerName: "श्रमिक नाम",
    healthScore: "स्वास्थ्य स्कोर",
    overallHealth: "कुल स्वास्थ्य",
    riskLevel: "जोखिम स्तर",
    parameters: "पैरामीटर",
    records: "स्वास्थ्य रिकॉर्ड",
    viewDetails: "विवरण देखें",
    jobRecs: "नौकरी सिफारिशें",
    filter: "फ़िल्टर",
    category: "श्रेणी",
    all: "सभी",
    lightDuty: "हल्का कार्य",
    mediumDuty: "मध्यम कार्य",
    heavyDuty: "कठिन कार्य",
    searchJobs: "नौकरियाँ खोजें...",
    apply: "आवेदन करें",
    saved: "सहेजा गया",
    save: "सहेजें",
    hospitalLocator: "नज़दीकी अस्पताल खोजें",
    yourLocation: "आपका स्थान",
    specialty: "विशेषज्ञता",
    distance: "दूरी",
    sortBy: "क्रमबद्ध करें",
    nearest: "सबसे नज़दीक",
    book: "बुक करें",
    bookAppointment: "अपॉइंटमेंट बुक करें",
    date: "तारीख",
    time: "समय",
    notes: "नोट्स",
    confirmBooking: "बुकिंग की पुष्टि करें",
    cancel: "रद्द करें",
    language: "भाषा",
    moderate: "मध्यम",
    high: "उच्च",
    low: "निम्न",
    suitability: "उपयुक्तता",
    recommended: "अनुशंसित",
    notSuitable: "उपयुक्त नहीं",
    details: "विवरण",
    loading: "लोड हो रहा है...",
  },
  bn: {
    dashboard: "অভিবাসী কর্মী ড্যাশবোর্ড",
    qrSection: "কিউআর কোড",
    generateQR: "জেনারেট",
    download: "ডাউনলোড",
    print: "প্রিন্ট",
    workerId: "কর্মী আইডি",
    workerName: "কর্মীর নাম",
    healthScore: "স্বাস্থ্য স্কোর",
    overallHealth: "সামগ্রিক স্বাস্থ্য",
    riskLevel: "ঝুঁকি স্তর",
    parameters: "প্যারামিটার",
    records: "স্বাস্থ্য রেকর্ড",
    viewDetails: "বিস্তারিত দেখুন",
    jobRecs: "চাকরির সুপারিশ",
    filter: "ফিল্টার",
    category: "বিভাগ",
    all: "সব",
    lightDuty: "হালকা কাজ",
    mediumDuty: "মাঝারি কাজ",
    heavyDuty: "কঠিন কাজ",
    searchJobs: "চাকরি খুঁজুন...",
    apply: "আবেদন",
    saved: "সংরক্ষিত",
    save: "সংরক্ষণ",
    hospitalLocator: "কাছাকাছি হাসপাতাল",
    yourLocation: "আপনার অবস্থান",
    specialty: "বিশেষত্ব",
    distance: "দূরত্ব",
    sortBy: "সাজান",
    nearest: "সর্বনিকট",
    book: "মুন্পতি঵ু",
    bookAppointment: "অ্যাপয়েন্টমেন্ট মুন্পতিভাগ",
    date: "তারিখ",
    time: "সময়",
    notes: "নোট",
    confirmBooking: "মুন্পতিভাগ উறুতি",
    cancel: "বাতিল",
    language: "ভাষা",
    moderate: "মধ্যম",
    high: "উচ্চ",
    low: "নিম্ন",
    suitability: "উপযুক্ততা",
    recommended: "সুপারিশকৃত",
    notSuitable: "উপযুক্ত নয়",
    details: "বিস্তারিত",
    loading: "লোড হচ্ছে...",
  },
  ta: {
    dashboard: "குடிவரவு தொழிலாளர் பலகை",
    qrSection: "QR குறியீடு",
    generateQR: "உருவாக்கு",
    download: "பதிவிறக்கு",
    print: "அச்சிடு",
    workerId: "தொழிலாளர் ஐடி",
    workerName: "தொழிலாளர் பெயர்",
    healthScore: "சுகாதார மதிப்பெண்",
    overallHealth: "மொத்த சுகாதாரம்",
    riskLevel: "அபாய நிலை",
    parameters: "அளவுருக்கள்",
    records: "மருத்துவ பதிவுகள்",
    viewDetails: "விவரங்கள்",
    jobRecs: "வேலை பரிந்துரைகள்",
    filter: "வடிகட்டி",
    category: "வகை",
    all: "அனைத்து",
    lightDuty: "இலகு பணி",
    mediumDuty: "மத்திய பணி",
    heavyDuty: "கடின பணி",
    searchJobs: "வேலைகள் தேடு...",
    apply: "விண்ணப்பி",
    saved: "சேமிக்கப்பட்டது",
    save: "சேமி",
    hospitalLocator: "அருகிலுள்ள மருத்துவமனை",
    yourLocation: "உங்கள் இடம்",
    specialty: "சிறப்பு",
    distance: "தூரம்",
    sortBy: "வரிசைப்படுத்து",
    nearest: "அருகிலுள்ள",
    book: "முன்பதிவு",
    bookAppointment: "நேர்முகம் முன்பதிவு",
    date: "தேதி",
    time: "நேரம்",
    notes: "குறிப்புகள்",
    confirmBooking: "முன்பதிவு உறுதி",
    cancel: "ரத்து",
    language: "மொழி",
    moderate: "மிதமான",
    high: "அதிக",
    low: "குறைந்த",
    suitability: "தகுதி",
    recommended: "பரிந்துரிக்கப்பட்டது",
    notSuitable: "தகுதியற்றது",
    details: "விவரங்கள்",
    loading: "ஏற்றுகிறது...",
  },
  ms: {
    dashboard: "Papan Pemuka Pekerja Migran",
    qrSection: "Kod QR",
    generateQR: "Jana",
    download: "Muat turun",
    print: "Cetak",
    workerId: "ID Pekerja",
    workerName: "Nama Pekerja",
    healthScore: "Skor Kesihatan",
    overallHealth: "Kesihatan Menyeluruh",
    riskLevel: "Tahap Risiko",
    parameters: "Parameter",
    records: "Rekod Kesihatan",
    viewDetails: "Lihat butiran",
    jobRecs: "Cadangan Kerja",
    filter: "Tapis",
    category: "Kategori",
    all: "Semua",
    lightDuty: "Kerja Ringan",
    mediumDuty: "Kerja Sederhana",
    heavyDuty: "Kerja Berat",
    searchJobs: "Cari kerja...",
    apply: "Mohon",
    saved: "Disimpan",
    save: "Simpan",
    hospitalLocator: "Pencari Hospital Berdekatan",
    yourLocation: "Lokasi anda",
    specialty: "Kepakaran",
    distance: "Jarak",
    sortBy: "Isih mengikut",
    nearest: "Terdekat",
    book: "Tempah",
    bookAppointment: "Tempah Temu Janji",
    date: "Tarikh",
    time: "Masa",
    notes: "Nota",
    confirmBooking: "Sahkan tempahan",
    cancel: "Batal",
    language: "Bahasa",
    moderate: "Sederhana",
    high: "Tinggi",
    low: "Rendah",
    suitability: "Kesesuaian",
    recommended: "Disyorkan",
    notSuitable: "Tidak sesuai",
    details: "Butiran",
    loading: "Memuat...",
  },
};

type HealthParam = {
  key: string;
  label: string;
  weight: number; // percent
  score: number; // 0-100
};

type Job = {
  id: string;
  title: string;
  company: string;
  category: "light" | "medium" | "heavy";
  description: string;
  requirements: string[];
  image: string;
};

type HospitalItem = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  specialty: string;
  address: string;
  phone: string;
};

export interface MigrantWorkerDashboardProps {
  className?: string;
  worker?: {
    id: string;
    name: string;
    nationality?: string;
  };
  initialLanguage?: Language;
  initialHealthParams?: HealthParam[];
  defaultLocation?: { lat: number; lng: number; label?: string };
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = (Math.PI / 180) * (b.lat - a.lat);
  const dLng = (Math.PI / 180) * (b.lng - a.lng);
  const lat1 = (Math.PI / 180) * a.lat;
  const lat2 = (Math.PI / 180) * b.lat;
  const sinDlat = Math.sin(dLat / 2);
  const sinDlng = Math.sin(dLng / 2);
  const h = sinDlat * sinDlat + Math.cos(lat1) * Math.cos(lat2) * sinDlng * sinDlng;
  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  return R * c;
}

function riskFromScore(score: number) {
  if (score >= 80) return { label: "low", color: "bg-emerald-500", text: "text-emerald-700", badge: "bg-emerald-100 text-emerald-700" };
  if (score >= 50) return { label: "moderate", color: "bg-amber-500", text: "text-amber-700", badge: "bg-amber-100 text-amber-700" };
  return { label: "high", color: "bg-red-500", text: "text-red-700", badge: "bg-red-100 text-red-700" };
}

const DEFAULT_PARAMS: HealthParam[] = [
  { key: "bmi", label: "BMI", weight: 20, score: 78 },
  { key: "bp", label: "Blood Pressure", weight: 25, score: 72 },
  { key: "hr", label: "Heart Rate", weight: 15, score: 85 },
  { key: "sleep", label: "Sleep Quality", weight: 20, score: 66 },
  { key: "steps", label: "Daily Activity", weight: 20, score: 74 },
];

const SAMPLE_JOBS: Job[] = [
  {
    id: "job-1",
    title: "Warehouse Packer",
    company: "Swift Logistics",
    category: "medium",
    description: "Prepare and pack shipments in a temperature-controlled facility.",
    requirements: ["Lift up to 15kg", "8-hour shifts", "Attention to detail"],
    image:
      "https://images.unsplash.com/photo-1544829081-ec71dd655b81?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "job-2",
    title: "Hotel Housekeeper",
    company: "BlueWave Hotels",
    category: "light",
    description: "Clean and prepare rooms while following safety standards.",
    requirements: ["Basic English", "Time management", "Customer focus"],
    image:
      "https://images.unsplash.com/photo-1603190287605-e6ade32fa852?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "job-3",
    title: "Construction Helper",
    company: "UrbanBuild Co.",
    category: "heavy",
    description: "Assist site supervisors with material handling and setup.",
    requirements: ["PPE required", "Long standing", "Outdoor work"],
    image:
      "https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "job-4",
    title: "Kitchen Assistant",
    company: "Daily Dine",
    category: "medium",
    description: "Support chefs with food prep and kitchen hygiene.",
    requirements: ["Standing for long periods", "Knife safety", "Teamwork"],
    image:
      "https://images.unsplash.com/photo-1504754524776-8f4f37790ca0?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "job-5",
    title: "Front Desk Attendant",
    company: "Harbor Residence",
    category: "light",
    description: "Assist guests with check-in and general inquiries.",
    requirements: ["Communication", "Basic computer use", "Shift flexibility"],
    image:
      "https://images.unsplash.com/photo-1563298723-dcfebaa392e3?q=80&w=1200&auto=format&fit=crop",
  },
];

const HOSPITALS: HospitalItem[] = [
  { id: "h1", name: "River Valley Clinic", lat: 1.305, lng: 103.83, specialty: "General", address: "12 River Rd", phone: "+65 6123 4567" },
  { id: "h2", name: "Metro Heart Center", lat: 1.312, lng: 103.845, specialty: "Cardiology", address: "88 Metro Ave", phone: "+65 6988 2211" },
  { id: "h3", name: "Sunrise Orthopedics", lat: 1.298, lng: 103.86, specialty: "Orthopedics", address: "45 Sunrise St", phone: "+65 6234 9988" },
  { id: "h4", name: "Harmony Medical", lat: 1.318, lng: 103.82, specialty: "General", address: "101 Harmony Pl", phone: "+65 6555 2323" },
];

export default function MigrantWorkerDashboard({
  className,
  worker = { id: "MW-2024-0001", name: "Amit Kumar" },
  initialLanguage = "en",
  initialHealthParams = DEFAULT_PARAMS,
  defaultLocation = { lat: 1.305, lng: 103.83, label: "Downtown" },
}: MigrantWorkerDashboardProps) {
  const [lang, setLang] = useState<Language>(initialLanguage);
  const t = i18n[lang];

  // Sidebar and section refs for in-page navigation
  const [navOpen, setNavOpen] = useState(false);
  const sectionRefs = {
    qr: useRef<HTMLDivElement | null>(null),
    health: useRef<HTMLDivElement | null>(null),
    jobs: useRef<HTMLDivElement | null>(null),
    hospitals: useRef<HTMLDivElement | null>(null),
    records: useRef<HTMLDivElement | null>(null),
  };
  const scrollTo = (key: keyof typeof sectionRefs) => {
    sectionRefs[key].current?.scrollIntoView({ behavior: "smooth", block: "start" });
    setNavOpen(false);
  };

  // QR state
  const [qrId, setQrId] = useState(worker.id);
  const [qrName, setQrName] = useState(worker.name);
  const [qrUrl, setQrUrl] = useState<string>("");
  const [qrLoading, setQrLoading] = useState(false);
  const qrCanvasRef = useRef<HTMLImageElement | null>(null);

  const qrPayload = useMemo(
    () =>
      JSON.stringify({
        type: "worker_health_card",
        id: qrId,
        name: qrName,
        ts: Date.now(),
      }),
    [qrId, qrName]
  );

  const generateQR = async () => {
    setQrLoading(true);
    try {
      const url = await QRCode.toDataURL(qrPayload, {
        margin: 1,
        width: 480,
        errorCorrectionLevel: "M",
        color: { dark: "#1f2b48", light: "#ffffff" },
      });
      setQrUrl(url);
      toast.success("QR updated");
    } catch (e) {
      toast.error("Failed to generate QR");
    } finally {
      setQrLoading(false);
    }
  };

  useEffect(() => {
    // initial generate on mount
    // avoid SSR window usage; safe here in effect
    generateQR();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const downloadQR = () => {
    if (!qrUrl) return;
    const link = document.createElement("a");
    link.href = qrUrl;
    link.download = `${qrId}-health-qr.png`;
    link.click();
  };

  const printQR = () => {
    if (!qrUrl) return;
    const win = window.open("", "_blank", "noopener,noreferrer,width=600,height=600");
    if (!win) return;
    win.document.write(`<html><head><title>QR</title></head><body style="margin:0;display:flex;align-items:center;justify-content:center;background:#fff"><img src="${qrUrl}" style="max-width:90%;height:auto"/></body></html>`);
    win.document.close();
    win.focus();
    setTimeout(() => {
      win.print();
      win.close();
    }, 300);
  };

  // Health score computation
  const [params, setParams] = useState<HealthParam[]>(initialHealthParams);
  const healthScore = useMemo(() => {
    const totalWeight = params.reduce((s, p) => s + p.weight, 0) || 1;
    const wScore = params.reduce((s, p) => s + (p.score * p.weight) / totalWeight, 0);
    return Math.round(wScore);
  }, [params]);
  const risk = riskFromScore(healthScore);

  // Jobs filters and dynamic recommendations
  const [jobQuery, setJobQuery] = useState("");
  const [jobCat, setJobCat] = useState<"all" | "light" | "medium" | "heavy">("all");
  const recommendedCategories = useMemo<("light" | "medium" | "heavy")[]>(() => {
    if (healthScore >= 80) return ["light", "medium", "heavy"];
    if (healthScore >= 50) return ["light", "medium"];
    return ["light"];
  }, [healthScore]);

  const jobs = useMemo(() => {
    const allowed = new Set(recommendedCategories);
    return SAMPLE_JOBS.filter((j) => {
      const categoryPass = jobCat === "all" ? true : j.category === jobCat;
      const recommendedPass = allowed.has(j.category);
      const queryPass =
        !jobQuery ||
        j.title.toLowerCase().includes(jobQuery.toLowerCase()) ||
        j.company.toLowerCase().includes(jobQuery.toLowerCase());
      return categoryPass && recommendedPass && queryPass;
    });
  }, [jobCat, jobQuery, recommendedCategories]);

  const [savedJobs, setSavedJobs] = useState<Set<string>>(new Set());
  const saveJob = (id: string) => {
    setSavedJobs((prev) => {
      const n = new Set(prev);
      if (n.has(id)) {
        n.delete(id);
        toast.message("Removed from saved");
      } else {
        n.add(id);
        toast.success("Job saved");
      }
      return n;
    });
  };

  // Hospitals
  const [locationLabel, setLocationLabel] = useState(defaultLocation.label ?? "");
  const [currentLoc, setCurrentLoc] = useState<{ lat: number; lng: number } | null>({
    lat: defaultLocation.lat,
    lng: defaultLocation.lng,
  });
  const [specialty, setSpecialty] = useState<string>("all");
  const [sort, setSort] = useState<string>("nearest");

  const hospitalsComputed = useMemo(() => {
    const base = HOSPITALS.filter((h) => (specialty === "all" ? true : h.specialty === specialty));
    if (!currentLoc) return base.map((h) => ({ ...h, distance: undefined as number | undefined }));
    const withDistance = base.map((h) => ({
      ...h,
      distance: haversineKm(currentLoc, { lat: h.lat, lng: h.lng }),
    }));
    if (sort === "nearest") {
      withDistance.sort((a, b) => (a.distance ?? 0) - (b.distance ?? 0));
    }
    return withDistance;
  }, [specialty, sort, currentLoc]);

  const [booking, setBooking] = useState<{ open: boolean; hospital?: HospitalItem }>({
    open: false,
  });
  const [bookingDate, setBookingDate] = useState("");
  const [bookingTime, setBookingTime] = useState("");
  const [bookingNotes, setBookingNotes] = useState("");

  // Records (simplified mock)
  const [records] = useState(
    [
      { id: "r1", date: "2025-07-12", type: "Check-up", summary: "Blood pressure slightly elevated.", details: "Advised to monitor BP twice a week and reduce sodium intake." },
      { id: "r2", date: "2025-06-03", type: "Lab Test", summary: "Normal CBC and glucose.", details: "All markers within normal range. Maintain current diet and exercise." },
      { id: "r3", date: "2025-04-27", type: "Vaccination", summary: "Tetanus booster administered.", details: "Next due in 10 years." },
    ] as const
  );
  const [recordDetail, setRecordDetail] = useState<{ open: boolean; record?: (typeof records)[number] }>({ open: false });

  // Responsive polish: animated score ring
  const circumference = 2 * Math.PI * 56;
  const ringOffset = circumference - (circumference * clamp(healthScore, 0, 100)) / 100;

  return (
    <div className={cn("w-full max-w-full", className)}>
      {/* Header */}
      <div className="flex items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <Sheet open={navOpen} onOpenChange={setNavOpen}>
            <SheetTrigger asChild>
              <Button variant="secondary" size="icon" className="bg-secondary text-foreground hover:bg-accent" aria-label="Open navigation">
                <PanelLeft className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="bg-sidebar-background p-0">
              <SheetHeader className="px-4 py-3 border-b">
                <SheetTitle className="flex items-center gap-2">
                  <LayoutDashboard className="h-5 w-5 text-sidebar-primary" />
                  <span className="font-heading">{t.dashboard}</span>
                </SheetTitle>
              </SheetHeader>
              <nav className="py-2">
                <button
                  onClick={() => scrollTo("qr")}
                  className="w-full text-left flex items-center gap-2 px-4 py-3 hover:bg-sidebar-accent"
                  aria-label="QR"
                >
                  <ScanQrCode className="h-4 w-4 text-sidebar-primary" />
                  <span>{t.qrSection}</span>
                </button>
                <button
                  onClick={() => scrollTo("health")}
                  className="w-full text-left flex items-center gap-2 px-4 py-3 hover:bg-sidebar-accent"
                  aria-label="Health score"
                >
                  <LayoutGrid className="h-4 w-4 text-sidebar-primary" />
                  <span>{t.healthScore}</span>
                </button>
                <button
                  onClick={() => scrollTo("jobs")}
                  className="w-full text-left flex items-center gap-2 px-4 py-3 hover:bg-sidebar-accent"
                  aria-label="Job recommendations"
                >
                  <PanelLeftClose className="h-4 w-4 text-sidebar-primary" />
                  <span>{t.jobRecs}</span>
                </button>
                <button
                  onClick={() => scrollTo("hospitals")}
                  className="w-full text-left flex items-center gap-2 px-4 py-3 hover:bg-sidebar-accent"
                  aria-label="Hospitals"
                >
                  <Hospital className="h-4 w-4 text-sidebar-primary" />
                  <span>{t.hospitalLocator}</span>
                </button>
                <button
                  onClick={() => scrollTo("records")}
                  className="w-full text-left flex items-center gap-2 px-4 py-3 hover:bg-sidebar-accent"
                  aria-label="Records"
                >
                  <LayoutDashboard className="h-4 w-4 text-sidebar-primary" />
                  <span>{t.records}</span>
                </button>
              </nav>
            </SheetContent>
          </Sheet>
          <div className="hidden sm:flex items-center gap-2 text-muted-foreground">
            <LayoutDashboard className="h-5 w-5" />
            <h2 className="text-base sm:text-lg md:text-xl font-heading">{t.dashboard}</h2>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor="lang" className="sr-only">
            {t.language}
          </Label>
          <Select value={lang} onValueChange={(v) => setLang(v as Language)}>
            <SelectTrigger id="lang" className="w-[120px] bg-card">
              <SelectValue placeholder={t.language} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="hi">हिंदी</SelectItem>
              <SelectItem value="bn">বাংলা</SelectItem>
              <SelectItem value="ta">தமிழ்</SelectItem>
              <SelectItem value="ms">Bahasa</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Content */}
      <div className="grid gap-4 md:gap-6">
        {/* Row 1: QR + Health */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 md:gap-6">
          <Card ref={sectionRefs.qr} className="bg-card">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <ScanQrCode className="h-5 w-5 text-primary" />
                    {t.qrSection}
                  </CardTitle>
                  <CardDescription className="mt-1">{worker.name}</CardDescription>
                </div>
                <Badge variant="secondary" className="bg-secondary text-foreground">
                  ID
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="qr-id">{t.workerId}</Label>
                  <Input
                    id="qr-id"
                    value={qrId}
                    onChange={(e) => setQrId(e.target.value)}
                    placeholder={t.workerId}
                    className="bg-card"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="qr-name">{t.workerName}</Label>
                  <Input
                    id="qr-name"
                    value={qrName}
                    onChange={(e) => setQrName(e.target.value)}
                    placeholder={t.workerName}
                    className="bg-card"
                  />
                </div>
              </div>
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                <div className="rounded-lg border bg-white p-3">
                  {qrUrl ? (
                    <img
                      ref={qrCanvasRef}
                      src={qrUrl}
                      alt="Worker health QR"
                      className="w-40 h-40 sm:w-44 sm:h-44"
                    />
                  ) : (
                    <div className="w-40 h-40 grid place-items-center text-sm text-muted-foreground">
                      {t.loading}
                    </div>
                  )}
                </div>
                <div className="flex flex-1 flex-wrap gap-2">
                  <Button onClick={generateQR} disabled={qrLoading} className="bg-primary text-primary-foreground hover:opacity-95">
                    {qrLoading ? t.loading : t.generateQR}
                  </Button>
                  <Button variant="secondary" onClick={downloadQR} disabled={!qrUrl}>
                    {t.download}
                  </Button>
                  <Button variant="outline" onClick={printQR} disabled={!qrUrl}>
                    {t.print}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card ref={sectionRefs.health} className="xl:col-span-2 bg-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <LayoutGrid className="h-5 w-5 text-primary" />
                  {t.healthScore}
                </CardTitle>
                <Badge className={cn("capitalize", risk.badge)}>
                  {t.riskLevel}: {i18n[lang][risk.label as keyof typeof i18n[typeof lang]]}
                </Badge>
              </div>
              <CardDescription>{t.overallHealth}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="flex items-center justify-center">
                  <div className="relative">
                    <svg width="160" height="160" viewBox="0 0 160 160" role="img" aria-label={`${t.healthScore}: ${healthScore}`}>
                      <circle cx="80" cy="80" r="56" stroke="#e5e7eb" strokeWidth="12" fill="none" />
                      <circle
                        cx="80"
                        cy="80"
                        r="56"
                        stroke="url(#grad)"
                        strokeWidth="12"
                        fill="none"
                        strokeDasharray={circumference}
                        strokeDashoffset={ringOffset}
                        strokeLinecap="round"
                        transform="rotate(-90 80 80)"
                      />
                      <defs>
                        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#4f7cff" />
                          <stop offset="100%" stopColor="#6aa8ff" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 grid place-items-center">
                      <div className="text-center">
                        <div className="text-3xl font-bold font-heading">{healthScore}</div>
                        <div className="text-xs text-muted-foreground">{t.healthScore}</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="lg:col-span-2 space-y-4">
                  <div className="text-sm font-medium">{t.parameters}</div>
                  <div className="space-y-3">
                    {params.map((p) => (
                      <div key={p.key} className="grid grid-cols-5 gap-3 items-center">
                        <div className="col-span-2 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium truncate">{p.label}</span>
                            <Badge variant="secondary" className="bg-secondary text-foreground">
                              {p.weight}%
                            </Badge>
                          </div>
                        </div>
                        <div className="col-span-3">
                          <Progress value={p.score} className="h-2" />
                          <div className="mt-1 text-xs text-muted-foreground">{p.score}/100</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Row 2: Records */}
        <Card ref={sectionRefs.records} className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <LayoutDashboard className="h-5 w-5 text-primary" />
              {t.records}
            </CardTitle>
            <CardDescription>{worker.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {records.map((rec) => (
                <div key={rec.id} className="rounded-lg border bg-white p-4 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{rec.type}</div>
                      <div className="text-xs text-muted-foreground">{rec.date}</div>
                    </div>
                    <Badge variant="secondary" className="bg-accent text-accent-foreground">
                      {t.details}
                    </Badge>
                  </div>
                  <p className="mt-2 text-sm line-clamp-2">{rec.summary}</p>
                  <div className="mt-3">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setRecordDetail({ open: true, record: rec })}
                    >
                      {t.viewDetails}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Row 3: Jobs + Hospitals */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          <Card ref={sectionRefs.jobs} className="bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <PanelLeftClose className="h-5 w-5 text-primary" />
                {t.jobRecs}
              </CardTitle>
              <CardDescription>
                {t.suitability}:{" "}
                {recommendedCategories.join(", ")}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="flex-1 min-w-0">
                  <Input
                    value={jobQuery}
                    onChange={(e) => setJobQuery(e.target.value)}
                    placeholder={t.searchJobs}
                    className="bg-card"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Label className="text-sm whitespace-nowrap">{t.category}</Label>
                  <Select value={jobCat} onValueChange={(v) => setJobCat(v as typeof jobCat)}>
                    <SelectTrigger className="w-[140px] bg-card">
                      <SelectValue placeholder={t.category} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t.all}</SelectItem>
                      <SelectItem value="light">{t.lightDuty}</SelectItem>
                      <SelectItem value="medium">{t.mediumDuty}</SelectItem>
                      <SelectItem value="heavy">{t.heavyDuty}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {jobs.map((job) => {
                  const isSaved = savedJobs.has(job.id);
                  const allowed = recommendedCategories.includes(job.category);
                  return (
                    <div key={job.id} className="border rounded-lg overflow-hidden bg-white flex flex-col">
                      <div className="relative overflow-hidden">
                        <img
                          src={job.image}
                          alt={job.title}
                          className="w-full h-32 object-cover"
                          loading="lazy"
                        />
                      </div>
                      <div className="p-4 flex flex-col gap-2 min-w-0">
                        <div className="flex items-center justify-between gap-3">
                          <div className="min-w-0">
                            <div className="font-medium truncate">{job.title}</div>
                            <div className="text-xs text-muted-foreground truncate">{job.company}</div>
                          </div>
                          <Badge
                            className={cn(
                              "capitalize",
                              job.category === "light" && "bg-emerald-100 text-emerald-700",
                              job.category === "medium" && "bg-amber-100 text-amber-700",
                              job.category === "heavy" && "bg-red-100 text-red-700"
                            )}
                          >
                            {job.category}
                          </Badge>
                        </div>
                        <p className="text-sm line-clamp-2">{job.description}</p>
                        <div className="flex flex-wrap gap-1">
                          {job.requirements.slice(0, 3).map((r) => (
                            <Badge key={r} variant="secondary" className="bg-secondary text-foreground">
                              {r}
                            </Badge>
                          ))}
                        </div>
                        <Separator className="my-2" />
                        <div className="flex items-center justify-between gap-2">
                          <Badge variant="outline" className={cn("text-xs", allowed ? "border-emerald-200 text-emerald-700" : "border-red-200 text-red-700")}>
                            {allowed ? t.recommended : t.notSuitable}
                          </Badge>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant={isSaved ? "secondary" : "outline"}
                              onClick={() => saveJob(job.id)}
                            >
                              {isSaved ? t.saved : t.save}
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => toast.success("Application submitted")}
                              disabled={!allowed}
                              className="bg-primary text-primary-foreground hover:opacity-95 disabled:opacity-60"
                            >
                              {t.apply}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                {jobs.length === 0 && (
                  <div className="col-span-full text-center text-sm text-muted-foreground py-8">
                    No jobs match your filters.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card ref={sectionRefs.hospitals} className="bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Hospital className="h-5 w-5 text-primary" />
                {t.hospitalLocator}
              </CardTitle>
              <CardDescription>{t.sortBy}: {t.nearest}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <Label htmlFor="loc">{t.yourLocation}</Label>
                  <Input
                    id="loc"
                    value={locationLabel}
                    onChange={(e) => setLocationLabel(e.target.value)}
                    placeholder="e.g., Downtown"
                    className="bg-card"
                  />
                  <div className="flex gap-2 mt-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        if (typeof navigator !== "undefined" && "geolocation" in navigator) {
                          navigator.geolocation.getCurrentPosition(
                            (pos) => {
                              setCurrentLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude });
                              toast.success("Location updated");
                            },
                            () => toast.error("Unable to get location"),
                            { enableHighAccuracy: true, timeout: 8000 }
                          );
                        } else {
                          toast.error("Geolocation not available");
                        }
                      }}
                    >
                      Use GPS
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setCurrentLoc({ lat: defaultLocation.lat, lng: defaultLocation.lng });
                        toast.message("Using default location");
                      }}
                    >
                      Reset
                    </Button>
                  </div>
                </div>
                <div className="sm:col-span-1">
                  <Label>{t.specialty}</Label>
                  <Select value={specialty} onValueChange={(v) => setSpecialty(v)}>
                    <SelectTrigger className="bg-card">
                      <SelectValue placeholder={t.specialty} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t.all}</SelectItem>
                      <SelectItem value="General">General</SelectItem>
                      <SelectItem value="Cardiology">Cardiology</SelectItem>
                      <SelectItem value="Orthopedics">Orthopedics</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="sm:col-span-1">
                  <Label>{t.sortBy}</Label>
                  <Select value={sort} onValueChange={(v) => setSort(v)}>
                    <SelectTrigger className="bg-card">
                      <SelectValue placeholder={t.sortBy} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nearest">{t.nearest}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Simple map integration: SVG with pins */}
              <div className="relative rounded-lg border bg-white overflow-hidden">
                <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,rgba(79,124,255,0.06),transparent_60%)]" />
                <div className="p-3 text-xs text-muted-foreground">{locationLabel || "Map"}</div>
                <svg viewBox="0 0 600 260" className="w-full h-48">
                  <rect x="0" y="0" width="600" height="260" fill="#eef3fb" />
                  {/* grid */}
                  {[...Array(10)].map((_, i) => (
                    <line key={`v${i}`} x1={(i + 1) * 60} y1="0" x2={(i + 1) * 60} y2="260" stroke="#e4e9f2" strokeWidth="1" />
                  ))}
                  {[...Array(4)].map((_, i) => (
                    <line key={`h${i}`} x1="0" y1={(i + 1) * 52} x2="600" y2={(i + 1) * 52} stroke="#e4e9f2" strokeWidth="1" />
                  ))}
                  {/* user position */}
                  {currentLoc && (
                    <circle cx={300} cy={130} r="6" fill="#4f7cff">
                      <title>You</title>
                    </circle>
                  )}
                  {/* hospital pins: project lat/lng relative to currentLoc for demo */}
                  {currentLoc &&
                    hospitalsComputed.map((h, idx) => {
                      const dx = (h.lng - currentLoc.lng) * 6000; // scale
                      const dy = (h.lat - currentLoc.lat) * -6000;
                      const x = clamp(300 + dx, 16, 584);
                      const y = clamp(130 + dy, 16, 244);
                      return (
                        <g key={h.id}>
                          <circle cx={x} cy={y} r="5" fill="#ef4444" />
                          <text x={x + 8} y={y - 8} fontSize="10" fill="#1f2b48">
                            {h.name}
                          </text>
                        </g>
                      );
                    })}
                </svg>
              </div>

              <div className="space-y-3">
                {hospitalsComputed.map((h) => (
                  <div key={h.id} className="border rounded-lg p-4 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{h.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{h.address} • {h.specialty}</div>
                      {typeof (h as any).distance === "number" && (
                        <div className="text-xs mt-1">
                          {t.distance}: {(h as any).distance.toFixed(1)} km
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          navigator.clipboard?.writeText(h.phone).catch(() => {});
                          toast.message(`Phone: ${h.phone}`);
                        }}
                      >
                        Call
                      </Button>
                      <Button
                        onClick={() => {
                          setBooking({ open: true, hospital: h });
                          setBookingDate("");
                          setBookingTime("");
                          setBookingNotes("");
                        }}
                        className="bg-primary text-primary-foreground hover:opacity-95"
                      >
                        {t.book}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Record details modal */}
      <Dialog open={recordDetail.open} onOpenChange={(o) => setRecordDetail((prev) => ({ open: o, record: o ? prev.record : undefined }))}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{recordDetail.record?.type}</DialogTitle>
            <DialogDescription>{recordDetail.record?.date}</DialogDescription>
          </DialogHeader>
          <div className="text-sm">{recordDetail.record?.summary}</div>
          <div className="text-sm text-muted-foreground mt-2">{recordDetail.record?.details}</div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setRecordDetail({ open: false })}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Appointment booking modal */}
      <Dialog open={booking.open} onOpenChange={(o) => setBooking((prev) => ({ ...prev, open: o }))}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{t.bookAppointment}</DialogTitle>
            <DialogDescription>{booking.hospital?.name}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="date">{t.date}</Label>
                <Input id="date" type="date" value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} className="bg-card" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time">{t.time}</Label>
                <Input id="time" type="time" value={bookingTime} onChange={(e) => setBookingTime(e.target.value)} className="bg-card" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">{t.notes}</Label>
              <Textarea id="notes" rows={3} value={bookingNotes} onChange={(e) => setBookingNotes(e.target.value)} placeholder="Any important information..." className="bg-card" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setBooking({ open: false })}>
              {t.cancel}
            </Button>
            <Button
              onClick={() => {
                if (!bookingDate || !bookingTime) {
                  toast.error("Please select date and time");
                  return;
                }
                toast.success("Appointment booked");
                setBooking({ open: false });
              }}
              className="bg-primary text-primary-foreground hover:opacity-95"
            >
              {t.confirmBooking}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}