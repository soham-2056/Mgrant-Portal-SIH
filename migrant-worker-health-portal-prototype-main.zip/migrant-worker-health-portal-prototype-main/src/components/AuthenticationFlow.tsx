"use client"

import * as React from "react"
import { LogIn, BadgeCheck, KeyRound, UserRound, IdCard, Check, LockKeyhole } from "lucide-react"
import { toast } from "sonner"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type Role = "worker" | "doctor" | "admin"
type Mode = "login" | "signup"
type SignupStep = "details" | "otp" | "password" | "success"

export interface AuthenticationFlowProps {
  className?: string
  style?: React.CSSProperties
  defaultRole?: Role
  defaultMode?: Mode
  onAuthSuccess?: (payload: { role: Role; token: string; userId: string }) => void
}

function simulateNetwork<T>(result: T, delay = 900, shouldFail = false): Promise<T> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (shouldFail) reject(new Error("Network error. Please try again."))
      else resolve(result)
    }, delay)
  })
}

function createSimulatedJWT(payload: Record<string, unknown>): string {
  const header = { alg: "HS256", typ: "JWT" }
  const enc = (obj: object) => typeof window !== "undefined" ? btoa(JSON.stringify(obj)) : Buffer.from(JSON.stringify(obj)).toString("base64")
  return `${enc(header)}.${enc(payload)}.signature`
}

export default function AuthenticationFlow({
  className,
  style,
  defaultRole = "worker",
  defaultMode = "login",
  onAuthSuccess,
}: AuthenticationFlowProps) {
  const [role, setRole] = React.useState<Role>(defaultRole)
  const [mode, setMode] = React.useState<Mode>(defaultMode)

  // Shared states
  const [isLoading, setIsLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  // Login state
  const [mobile, setMobile] = React.useState("")
  const [proId, setProId] = React.useState("")
  const [password, setPassword] = React.useState("")
  const [showPassword, setShowPassword] = React.useState(false)

  // Signup state
  const [signupStep, setSignupStep] = React.useState<SignupStep>("details")
  const [signupMobile, setSignupMobile] = React.useState("")
  const [signupProId, setSignupProId] = React.useState("")
  const [otp, setOtp] = React.useState("")
  const [otpSent, setOtpSent] = React.useState(false)
  const [resendIn, setResendIn] = React.useState(0)
  const [signupPassword, setSignupPassword] = React.useState("")
  const [signupConfirm, setSignupConfirm] = React.useState("")
  const [signupShowPassword, setSignupShowPassword] = React.useState(false)
  const otpRef = React.useRef<HTMLInputElement | null>(null)

  React.useEffect(() => {
    // reset errors on mode/role change
    setError(null)
  }, [mode, role])

  React.useEffect(() => {
    let timer: number | undefined
    if (resendIn > 0) {
      timer = window.setInterval(() => setResendIn((s) => (s > 0 ? s - 1 : 0)), 1000)
    }
    return () => {
      if (timer) window.clearInterval(timer)
    }
  }, [resendIn])

  // Validation helpers
  const isValidMobile = (val: string) => /^[0-9]{8,15}$/.test(val.replace(/\s+/g, ""))
  const isValidProId = (val: string) => /^[A-Za-z0-9\-]{4,20}$/.test(val.trim())
  const isStrongPassword = (val: string) => /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d\W]{8,64}$/.test(val)

  const resetForm = () => {
    setMobile("")
    setProId("")
    setPassword("")
    setShowPassword(false)
    setSignupStep("details")
    setSignupMobile("")
    setSignupProId("")
    setOtp("")
    setOtpSent(false)
    setResendIn(0)
    setSignupPassword("")
    setSignupConfirm("")
    setSignupShowPassword(false)
    setError(null)
    setIsLoading(false)
  }

  const handleRoleChange = (next: Role) => {
    setRole(next)
    resetForm()
  }

  const handleModeChange = (next: Mode) => {
    setMode(next)
    // keep role, reset internals
    setError(null)
    setIsLoading(false)
    setSignupStep("details")
    setOtp("")
    setOtpSent(false)
    setResendIn(0)
  }

  async function onLoginSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (role === "worker") {
      if (!isValidMobile(mobile)) {
        setError("Enter a valid mobile number (8–15 digits).")
        return
      }
    } else {
      if (!isValidProId(proId)) {
        setError("Enter a valid professional ID (4–20 alphanumeric).")
        return
      }
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.")
      return
    }

    setIsLoading(true)
    try {
      // simulate API
      await simulateNetwork(true, 900)
      const userId =
        role === "worker"
          ? `mw_${mobile.slice(-6)}`
          : role === "doctor"
          ? `dr_${proId.slice(0, 6)}`
          : `ga_${proId.slice(0, 6)}`
      const token = createSimulatedJWT({
        sub: userId,
        role,
        exp: Math.floor(Date.now() / 1000) + 60 * 60 * 4,
      })
      toast.success("Login successful", { description: "Redirecting to your dashboard..." })
      onAuthSuccess?.({ role, token, userId })
      resetForm()
    } catch (err) {
      setError((err as Error).message || "Unable to login. Please try again.")
      toast.error("Login failed", { description: "Please check your details and try again." })
    } finally {
      setIsLoading(false)
    }
  }

  async function onSignupDetailsSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (role === "worker") {
      if (!isValidMobile(signupMobile)) {
        setError("Enter a valid mobile number (8–15 digits).")
        return
      }
    } else {
      if (!isValidProId(signupProId)) {
        setError("Enter a valid professional ID (4–20 alphanumeric).")
        return
      }
    }

    setIsLoading(true)
    try {
      // simulate sending OTP
      await simulateNetwork(true, 900)
      setOtpSent(true)
      setResendIn(30)
      setSignupStep("otp")
      toast.message("OTP sent", {
        description:
          role === "worker"
            ? "We sent a 6-digit code to your mobile number."
            : "We sent a 6-digit code to your registered contact.",
      })
      // focus OTP
      setTimeout(() => otpRef.current?.focus(), 50)
    } catch {
      setError("Failed to send OTP. Please try again.")
      toast.error("OTP not sent", { description: "Please check your details and retry." })
    } finally {
      setIsLoading(false)
    }
  }

  async function onVerifyOtp(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (!/^\d{6}$/.test(otp)) {
      setError("Enter the 6-digit OTP code.")
      return
    }
    setIsLoading(true)
    try {
      // simulate OTP verification
      await simulateNetwork(true, 800, otp !== "123456")
      setSignupStep("password")
      toast.success("OTP verified", { description: "Create a strong password to finish signup." })
    } catch {
      setError("Invalid OTP. Use 123456 for demo.")
      toast.error("OTP verification failed", { description: "Please try again." })
    } finally {
      setIsLoading(false)
    }
  }

  async function onCreatePassword(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (!isStrongPassword(signupPassword)) {
      setError("Password must be 8+ chars with letters and numbers.")
      return
    }
    if (signupPassword !== signupConfirm) {
      setError("Passwords do not match.")
      return
    }
    setIsLoading(true)
    try {
      await simulateNetwork(true, 900)
      setSignupStep("success")
      const userId =
        role === "worker"
          ? `mw_${signupMobile.slice(-6)}`
          : role === "doctor"
          ? `dr_${signupProId.slice(0, 6)}`
          : `ga_${signupProId.slice(0, 6)}`
      const token = createSimulatedJWT({
        sub: userId,
        role,
        exp: Math.floor(Date.now() / 1000) + 60 * 60 * 4,
      })
      toast.success("Account created", { description: "You are now signed in." })
      onAuthSuccess?.({ role, token, userId })
      // Keep success state visible briefly
      setTimeout(() => {
        resetForm()
        setMode("login")
      }, 1200)
    } catch {
      setError("Could not create account. Please try later.")
      toast.error("Signup failed", { description: "Please try again." })
    } finally {
      setIsLoading(false)
    }
  }

  const roleIcon =
    role === "worker" ? <UserRound className="h-5 w-5 text-primary" aria-hidden="true" /> : <IdCard className="h-5 w-5 text-primary" aria-hidden="true" />

  return (
    <Card className={["w-full max-w-md bg-card shadow-sm border-border", className].filter(Boolean).join(" ")} style={style}>
      <CardHeader className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="inline-flex h-9 w-9 items-center justify-center rounded-md bg-secondary">
            {roleIcon}
          </div>
          <div className="min-w-0">
            <CardTitle className="text-base sm:text-lg font-semibold truncate">
              {mode === "login" ? "Welcome back" : "Create your account"}
            </CardTitle>
            <CardDescription className="text-sm">
              {role === "worker" ? "Migrant Worker Portal" : role === "doctor" ? "Doctor Portal" : "Government Admin Portal"}
            </CardDescription>
          </div>
        </div>

        <Tabs value={role} onValueChange={(v) => handleRoleChange(v as Role)} className="w-full">
          <TabsList className="grid grid-cols-3">
            <TabsTrigger value="worker" className="text-xs sm:text-sm">Worker</TabsTrigger>
            <TabsTrigger value="doctor" className="text-xs sm:text-sm">Doctor</TabsTrigger>
            <TabsTrigger value="admin" className="text-xs sm:text-sm">Admin</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center justify-between rounded-md bg-secondary px-2 py-1.5">
          <div className="flex items-center gap-2">
            {mode === "login" ? <LogIn className="h-4 w-4 text-primary" /> : <BadgeCheck className="h-4 w-4 text-primary" />}
            <span className="text-xs sm:text-sm font-medium">{mode === "login" ? "Login" : "Sign up"}</span>
          </div>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="text-xs sm:text-sm"
            onClick={() => handleModeChange(mode === "login" ? "signup" : "login")}
          >
            {mode === "login" ? "Create account" : "Have an account? Login"}
          </Button>
        </div>

        {mode === "login" ? (
          <form onSubmit={onLoginSubmit} className="space-y-4">
            {role === "worker" ? (
              <div className="space-y-2">
                <Label htmlFor="mobile">Mobile number</Label>
                <Input
                  id="mobile"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={15}
                  placeholder="e.g., 9876543210"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D+/g, ""))}
                  aria-invalid={!!error}
                  autoComplete="tel"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="proId">{role === "doctor" ? "Doctor Registration ID" : "Admin ID"}</Label>
                <Input
                  id="proId"
                  placeholder={role === "doctor" ? "e.g., DR-4573" : "e.g., GOV-0091"}
                  value={proId}
                  onChange={(e) => setProId(e.target.value.trim())}
                  aria-invalid={!!error}
                  autoCapitalize="characters"
                />
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button
                  type="button"
                  className="text-xs text-primary hover:underline"
                  onClick={() => setShowPassword((s) => !s)}
                  aria-pressed={showPassword}
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  aria-invalid={!!error}
                />
                <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
              </div>
            </div>

            {error && (
              <p role="alert" className="text-sm text-destructive break-words">
                {error}
              </p>
            )}

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? "Signing in..." : "Sign in"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              By continuing, you agree to our terms and privacy policy.
            </p>
          </form>
        ) : (
          <div className="space-y-4">
            {signupStep === "details" && (
              <form onSubmit={onSignupDetailsSubmit} className="space-y-4 animate-in fade-in-0 slide-in-from-top-1 duration-200">
                {role === "worker" ? (
                  <div className="space-y-2">
                    <Label htmlFor="signup-mobile">Mobile number</Label>
                    <Input
                      id="signup-mobile"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={15}
                      placeholder="e.g., 9876543210"
                      value={signupMobile}
                      onChange={(e) => setSignupMobile(e.target.value.replace(/\D+/g, ""))}
                      autoComplete="tel"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="signup-proid">{role === "doctor" ? "Doctor Registration ID" : "Admin ID"}</Label>
                    <Input
                      id="signup-proid"
                      placeholder={role === "doctor" ? "e.g., DR-4573" : "e.g., GOV-0091"}
                      value={signupProId}
                      onChange={(e) => setSignupProId(e.target.value.trim())}
                      autoCapitalize="characters"
                    />
                  </div>
                )}

                {error && (
                  <p role="alert" className="text-sm text-destructive break-words">
                    {error}
                  </p>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Sending code..." : "Send verification code"}
                </Button>
              </form>
            )}

            {signupStep === "otp" && (
              <form onSubmit={onVerifyOtp} className="space-y-4 animate-in fade-in-0 slide-in-from-top-1 duration-200">
                <div className="flex items-center gap-2 rounded-md bg-secondary px-3 py-2">
                  <LockKeyhole className="h-4 w-4 text-primary" />
                  <p className="text-sm">
                    Enter the 6-digit OTP sent to {role === "worker" ? "your mobile" : "your registered contact"}.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="otp">One-Time Password</Label>
                  <Input
                    id="otp"
                    ref={otpRef}
                    inputMode="numeric"
                    pattern="[0-9]*"
                    placeholder="Enter 6-digit code (try 123456)"
                    maxLength={6}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D+/g, ""))}
                    aria-invalid={!!error}
                  />
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{otpSent ? "Code sent" : "Waiting to send..."}</span>
                    <button
                      type="button"
                      onClick={async () => {
                        if (resendIn > 0 || isLoading) return
                        setIsLoading(true)
                        try {
                          await simulateNetwork(true, 700)
                          setOtp("")
                          setResendIn(30)
                          toast.message("New OTP sent")
                        } finally {
                          setIsLoading(false)
                        }
                      }}
                      className={`hover:underline ${resendIn > 0 ? "opacity-50 cursor-not-allowed" : ""}`}
                      aria-disabled={resendIn > 0}
                    >
                      {resendIn > 0 ? `Resend in ${resendIn}s` : "Resend code"}
                    </button>
                  </div>
                </div>

                {error && (
                  <p role="alert" className="text-sm text-destructive break-words">
                    {error}
                  </p>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Verifying..." : "Verify code"}
                </Button>
              </form>
            )}

            {signupStep === "password" && (
              <form onSubmit={onCreatePassword} className="space-y-4 animate-in fade-in-0 slide-in-from-top-1 duration-200">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="signup-password">Create password</Label>
                    <button
                      type="button"
                      className="text-xs text-primary hover:underline"
                      onClick={() => setSignupShowPassword((s) => !s)}
                      aria-pressed={signupShowPassword}
                    >
                      {signupShowPassword ? "Hide" : "Show"}
                    </button>
                  </div>
                  <Input
                    id="signup-password"
                    type={signupShowPassword ? "text" : "password"}
                    placeholder="8+ characters, letters & numbers"
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    autoComplete="new-password"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-confirm">Confirm password</Label>
                  <Input
                    id="signup-confirm"
                    type={signupShowPassword ? "text" : "password"}
                    placeholder="Re-enter password"
                    value={signupConfirm}
                    onChange={(e) => setSignupConfirm(e.target.value)}
                    autoComplete="new-password"
                  />
                </div>

                <ul className="text-xs text-muted-foreground space-y-1">
                  <li className={isStrongPassword(signupPassword) ? "text-green-600" : ""}>• At least 8 characters</li>
                  <li className={/[A-Za-z]/.test(signupPassword) ? "text-green-600" : ""}>• Contains a letter</li>
                  <li className={/\d/.test(signupPassword) ? "text-green-600" : ""}>• Contains a number</li>
                </ul>

                {error && (
                  <p role="alert" className="text-sm text-destructive break-words">
                    {error}
                  </p>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Creating account..." : "Create account"}
                </Button>
              </form>
            )}

            {signupStep === "success" && (
              <div className="space-y-3 text-center animate-in fade-in-0 zoom-in-95 duration-200">
                <div className="mx-auto h-10 w-10 rounded-full bg-accent flex items-center justify-center">
                  <Check className="h-6 w-6 text-primary" />
                </div>
                <p className="text-sm font-medium">You're all set!</p>
                <p className="text-sm text-muted-foreground">Redirecting to your dashboard...</p>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-center gap-2 pt-1">
          <div className="h-px w-6 bg-border" />
          <span className="text-[11px] uppercase tracking-wide text-muted-foreground">Secure by design</span>
          <div className="h-px w-6 bg-border" />
        </div>
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <KeyRound className="h-3.5 w-3.5" />
          <span>Encrypted transmission • Simulated JWT</span>
        </div>
      </CardContent>
    </Card>
  )
}