"use client"

import * as React from "react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { PanelLeft, LayoutDashboard, Hospital, ScanQrCode, SearchCheck, FileHeart, ScanHeart, ScanSearch } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Switch } from "@/components/ui/switch"

type RiskLevel = "low" | "medium" | "high"

type Vital = {
  label: string
  value: string
  range: string
}

type LabResult = {
  name: string
  value: string
  unit?: string
  status: "normal" | "attention" | "critical"
}

type Diagnosis = {
  condition: string
  date: string
  notes?: string
}

type Patient = {
  id: string
  healthId: string
  firstName: string
  lastName: string
  age: number
  sex: "Male" | "Female" | "Other"
  phone?: string
  lastVisit: string
  risk: RiskLevel
  chronic: string[]
  symptoms: string[]
  diagnoses: Diagnosis[]
  vitals: Vital[]
  labs: LabResult[]
  summary: string
  sensitive?: {
    hivStatus?: "Negative" | "Positive" | "Unknown"
    mentalHealthNotes?: string
  }
}

const MOCK_PATIENTS: Patient[] = [
  {
    id: "p-001",
    healthId: "HID-9X2A-44",
    firstName: "Amina",
    lastName: "Khan",
    age: 29,
    sex: "Female",
    phone: "+65 8123 4567",
    lastVisit: "2025-09-01",
    risk: "medium",
    chronic: ["Iron-deficiency anemia"],
    symptoms: ["Fatigue", "Dizziness"],
    diagnoses: [
      { condition: "Anemia", date: "2025-08-10", notes: "Started iron supplementation" },
    ],
    vitals: [
      { label: "BP", value: "108/72", range: "90-120 / 60-80 mmHg" },
      { label: "HR", value: "78 bpm", range: "60-100 bpm" },
      { label: "SpO₂", value: "98%", range: "≥ 95%" },
      { label: "Temp", value: "36.8°C", range: "36.1-37.2°C" },
    ],
    labs: [
      { name: "Hemoglobin", value: "10.5", unit: "g/dL", status: "attention" },
      { name: "Ferritin", value: "12", unit: "ng/mL", status: "attention" },
      { name: "Glucose (F)", value: "92", unit: "mg/dL", status: "normal" },
    ],
    summary:
      "Mild anemia under treatment. Energy improving. Recommend dietary counseling, continue iron, recheck CBC in 4 weeks.",
    sensitive: {
      hivStatus: "Negative",
    },
  },
  {
    id: "p-002",
    healthId: "HID-7TBQ-12",
    firstName: "Rahul",
    lastName: "Patel",
    age: 41,
    sex: "Male",
    phone: "+65 9090 1212",
    lastVisit: "2025-09-07",
    risk: "high",
    chronic: ["Type 2 Diabetes", "Hypertension"],
    symptoms: ["Polyuria", "Blurred vision"],
    diagnoses: [
      { condition: "Uncontrolled T2DM", date: "2025-09-07", notes: "Adjusted metformin; add SGLT2i" },
      { condition: "Hypertension", date: "2024-12-13" },
    ],
    vitals: [
      { label: "BP", value: "152/96", range: "90-120 / 60-80 mmHg" },
      { label: "HR", value: "88 bpm", range: "60-100 bpm" },
      { label: "SpO₂", value: "97%", range: "≥ 95%" },
      { label: "Temp", value: "37.1°C", range: "36.1-37.2°C" },
    ],
    labs: [
      { name: "HbA1c", value: "9.2", unit: "%", status: "critical" },
      { name: "LDL-C", value: "148", unit: "mg/dL", status: "attention" },
      { name: "Creatinine", value: "0.9", unit: "mg/dL", status: "normal" },
    ],
    summary:
      "Elevated HbA1c with symptomatic hyperglycemia. Intensify therapy, SMBG education, follow-up in 2 weeks. Consider lifestyle coaching.",
    sensitive: {
      mentalHealthNotes: "Reports work-related stress, PHQ-9 score 8 (mild).",
    },
  },
  {
    id: "p-003",
    healthId: "HID-5LMN-88",
    firstName: "Siti",
    lastName: "Nur",
    age: 34,
    sex: "Female",
    phone: "+65 8111 9090",
    lastVisit: "2025-08-22",
    risk: "low",
    chronic: ["None"],
    symptoms: [],
    diagnoses: [{ condition: "Routine check", date: "2025-08-22" }],
    vitals: [
      { label: "BP", value: "112/74", range: "90-120 / 60-80 mmHg" },
      { label: "HR", value: "72 bpm", range: "60-100 bpm" },
      { label: "SpO₂", value: "99%", range: "≥ 95%" },
      { label: "Temp", value: "36.6°C", range: "36.1-37.2°C" },
    ],
    labs: [
      { name: "Hemoglobin", value: "13.1", unit: "g/dL", status: "normal" },
      { name: "Glucose (F)", value: "88", unit: "mg/dL", status: "normal" },
    ],
    summary:
      "Healthy examination. Encourage routine exercise and balanced diet. Next annual check in 12 months.",
  },
]

type NewPatient = {
  firstName: string
  lastName: string
  sex: "Male" | "Female" | "Other"
  age: number | ""
  phone?: string
}

interface DoctorPortalProps {
  className?: string
}

export default function DoctorPortal({ className }: DoctorPortalProps) {
  const [patients, setPatients] = React.useState<Patient[]>(MOCK_PATIENTS)
  const [query, setQuery] = React.useState("")
  const [searchBy, setSearchBy] = React.useState<"name" | "healthId">("name")
  const [selectedPatientId, setSelectedPatientId] = React.useState<string | null>(patients[0]?.id ?? null)

  const [isScanOpen, setIsScanOpen] = React.useState(false)
  const [isNewOpen, setIsNewOpen] = React.useState(false)
  const [isApptOpen, setIsApptOpen] = React.useState(false)
  const [isSmsOpen, setIsSmsOpen] = React.useState(false)
  const [isUnlockOpen, setIsUnlockOpen] = React.useState(false)
  const [isUnlocked, setIsUnlocked] = React.useState(false)
  const [navOpen, setNavOpen] = React.useState(false)

  const selectedPatient = React.useMemo(
    () => patients.find((p) => p.id === selectedPatientId) ?? null,
    [patients, selectedPatientId]
  )

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return patients
    if (searchBy === "healthId") {
      return patients.filter((p) => p.healthId.toLowerCase().includes(q))
    }
    return patients.filter((p) =>
      `${p.firstName} ${p.lastName}`.toLowerCase().includes(q)
    )
  }, [patients, query, searchBy])

  function riskBadge(level: RiskLevel) {
    const map: Record<RiskLevel, { className: string; label: string }> = {
      low: { className: "bg-muted text-foreground", label: "Low Risk" },
      medium: { className: "bg-accent text-accent-foreground", label: "Moderate Risk" },
      high: { className: "bg-destructive text-destructive-foreground", label: "High Risk" },
    }
    const m = map[level]
    return <span className={cn("inline-flex rounded-full px-2.5 py-1 text-xs font-medium", m.className)}>{m.label}</span>
  }

  function handleCreatePatient(data: NewPatient) {
    const id = `p-${Math.random().toString(36).slice(2, 6)}`
    const healthId = `HID-${Math.random().toString(36).slice(2, 4).toUpperCase()}${Math.floor(Math.random() * 9)}-${Math.floor(Math.random() * 90 + 10)}`
    const newPatient: Patient = {
      id,
      healthId,
      firstName: data.firstName,
      lastName: data.lastName,
      age: Number(data.age) || 0,
      sex: data.sex,
      phone: data.phone,
      lastVisit: new Date().toISOString().slice(0, 10),
      risk: "low",
      chronic: ["None"],
      symptoms: [],
      diagnoses: [{ condition: "New registration", date: new Date().toISOString().slice(0, 10) }],
      vitals: [
        { label: "BP", value: "—", range: "90-120 / 60-80 mmHg" },
        { label: "HR", value: "—", range: "60-100 bpm" },
        { label: "SpO₂", value: "—", range: "≥ 95%" },
        { label: "Temp", value: "—", range: "36.1-37.2°C" },
      ],
      labs: [],
      summary: "Profile created. No clinical data yet.",
    }
    setPatients((prev) => [newPatient, ...prev])
    setSelectedPatientId(id)
    toast.success("New patient profile created")
  }

  function simulateScan() {
    // Randomly select a patient to simulate a scan match
    const idx = Math.floor(Math.random() * patients.length)
    const p = patients[idx]
    setSelectedPatientId(p.id)
    setIsScanOpen(false)
    toast.message("QR scan matched", { description: `${p.firstName} ${p.lastName} • ${p.healthId}` })
  }

  function scheduleAppt(patient: Patient | null, datetime: string, reason: string) {
    if (!patient) return
    toast.success("Appointment scheduled", {
      description: `${patient.firstName} ${patient.lastName} on ${new Date(datetime).toLocaleString()}`,
    })
    setIsApptOpen(false)
  }

  function sendSms(patient: Patient | null, phone: string, msg: string) {
    if (!patient) return
    if (!phone || !msg) {
      toast.error("SMS not sent", { description: "Phone and message are required" })
      return
    }
    toast.message("Follow-up SMS queued", { description: `To ${phone}: ${msg.slice(0, 80)}${msg.length > 80 ? "..." : ""}` })
    setIsSmsOpen(false)
  }

  function unlockSensitive(pin: string) {
    if (pin === "1234") {
      setIsUnlocked(true)
      setIsUnlockOpen(false)
      toast.success("Sensitive data unlocked", { description: "Access will reset after you navigate away" })
    } else {
      toast.error("Invalid PIN", { description: "Please try again" })
    }
  }

  return (
    <section className={cn("w-full max-w-full", className)}>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sheet open={navOpen} onOpenChange={setNavOpen}>
            <SheetTrigger asChild>
              <Button variant="secondary" size="icon" className="sm:hidden" aria-label="Open navigation">
                <PanelLeft className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 bg-sidebar text-sidebar-foreground">
              <SheetHeader>
                <SheetTitle className="font-heading text-lg text-foreground">Doctor Portal</SheetTitle>
              </SheetHeader>
              <nav className="mt-4 space-y-1">
                <NavItem icon={<LayoutDashboard className="h-4 w-4" />} label="Dashboard" active />
                <NavItem icon={<Hospital className="h-4 w-4" />} label="Patients" />
                <NavItem icon={<FileHeart className="h-4 w-4" />} label="Records" />
              </nav>
            </SheetContent>
          </Sheet>
          <h2 className="text-base sm:text-lg md:text-xl font-heading">Doctor Portal</h2>
          <Badge variant="secondary" className="hidden sm:inline-flex">Migrant Worker Health</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={isScanOpen} onOpenChange={setIsScanOpen}>
            <DialogTrigger asChild>
              <Button variant="secondary" className="gap-2">
                <ScanQrCode className="h-4 w-4" />
                Simulate QR Scan
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Scan Health QR</DialogTitle>
                <DialogDescription>Simulate scanning a patient QR to quickly open their profile.</DialogDescription>
              </DialogHeader>
              <div className="rounded-md border bg-card p-4">
                <div className="flex items-center justify-center rounded-md bg-muted/60 p-10">
                  <ScanHeart className="h-10 w-10 text-muted-foreground" aria-hidden="true" />
                </div>
                <p className="mt-3 text-sm text-muted-foreground">This is a simulation for development and demos.</p>
              </div>
              <DialogFooter className="gap-2">
                <Button onClick={simulateScan} className="w-full sm:w-auto">
                  <ScanSearch className="mr-2 h-4 w-4" />
                  Scan & Match
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-[320px_1fr]">
        {/* Sidebar card (persistent on md+, collapsible via Sheet on mobile) */}
        <Card className="bg-card md:sticky md:top-4 md:h-fit">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Patient Search</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <Select value={searchBy} onValueChange={(v) => setSearchBy(v as "name" | "healthId")}>
                <SelectTrigger className="w-[130px]" aria-label="Search by">
                  <SelectValue placeholder="Search by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="healthId">Health ID</SelectItem>
                </SelectContent>
              </Select>
              <div className="relative min-w-0 flex-1">
                <SearchCheck className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  className="pl-8"
                  placeholder={searchBy === "name" ? "Search by name..." : "Search by Health ID..."}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  aria-label="Search patients"
                />
              </div>
            </div>
            <Separator />
            <div className="space-y-1 max-h-[360px] overflow-y-auto pr-1">
              {filtered.length === 0 ? (
                <p className="text-sm text-muted-foreground">No patients found.</p>
              ) : (
                filtered.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedPatientId(p.id)}
                    className={cn(
                      "w-full rounded-md border p-3 text-left transition-colors",
                      "hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                      selectedPatientId === p.id ? "bg-secondary" : "bg-card"
                    )}
                    aria-pressed={selectedPatientId === p.id}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate font-medium">{p.firstName} {p.lastName}</p>
                        <p className="truncate text-xs text-muted-foreground">{p.healthId}</p>
                      </div>
                      {riskBadge(p.risk)}
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span>Last visit: {p.lastVisit}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="truncate">Chronic: {p.chronic.join(", ")}</span>
                    </div>
                  </button>
                ))
              )}
            </div>
            <Separator />
            <Dialog open={isNewOpen} onOpenChange={setIsNewOpen}>
              <DialogTrigger asChild>
                <Button className="w-full">Create New Patient</Button>
              </DialogTrigger>
              <NewPatientForm
                onSubmit={(data) => {
                  handleCreatePatient(data)
                  setIsNewOpen(false)
                }}
              />
            </Dialog>
          </CardContent>
        </Card>

        {/* Main content */}
        <div className="min-w-0 space-y-4">
          {selectedPatient ? (
            <>
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <CardTitle className="text-lg sm:text-xl">
                        {selectedPatient.firstName} {selectedPatient.lastName}
                      </CardTitle>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                        <span className="truncate">Health ID: {selectedPatient.healthId}</span>
                        <span>•</span>
                        <span>Age: {selectedPatient.age}</span>
                        <span>•</span>
                        <span>Sex: {selectedPatient.sex}</span>
                        {selectedPatient.phone ? (
                          <>
                            <span className="hidden sm:inline">•</span>
                            <span className="truncate">{selectedPatient.phone}</span>
                          </>
                        ) : null}
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-2">
                      {riskBadge(selectedPatient.risk)}
                      <div className="flex items-center gap-2">
                        <Dialog open={isApptOpen} onOpenChange={setIsApptOpen}>
                          <DialogTrigger asChild>
                            <Button variant="secondary" className="gap-2">
                              <Hospital className="h-4 w-4" />
                              Schedule
                            </Button>
                          </DialogTrigger>
                          <ScheduleDialog
                            onSubmit={(dt, reason) => scheduleAppt(selectedPatient, dt, reason)}
                          />
                        </Dialog>
                        <Dialog open={isSmsOpen} onOpenChange={setIsSmsOpen}>
                          <DialogTrigger asChild>
                            <Button variant="secondary" className="gap-2">
                              <ScanSearch className="h-4 w-4" />
                              SMS Alert
                            </Button>
                          </DialogTrigger>
                          <SmsDialog
                            defaultPhone={selectedPatient.phone ?? ""}
                            onSend={(phone, msg) => sendSms(selectedPatient, phone, msg)}
                          />
                        </Dialog>
                        <Dialog open={isUnlockOpen} onOpenChange={setIsUnlockOpen}>
                          <DialogTrigger asChild>
                            <Button variant={isUnlocked ? "default" : "secondary"} className="gap-2">
                              <LayoutDashboard className="h-4 w-4" />
                              {isUnlocked ? "Sensitive: Unlocked" : "Unlock Sensitive"}
                            </Button>
                          </DialogTrigger>
                          <UnlockDialog onVerify={unlockSensitive} />
                        </Dialog>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="grid gap-4 sm:grid-cols-2">
                  <InfoStat label="Last Visit" value={selectedPatient.lastVisit} />
                  <InfoStat label="Chronic" value={selectedPatient.chronic.join(", ")} />
                  <InfoStat label="Symptoms" value={selectedPatient.symptoms.length ? selectedPatient.symptoms.join(", ") : "None reported"} />
                  <div className="sm:col-span-2">
                    <div className="rounded-md border p-3">
                      <p className="text-sm font-medium">Automated Health Summary</p>
                      <p className="mt-1 text-sm text-muted-foreground break-words">{selectedPatient.summary}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="bg-secondary">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="vitals">Vitals</TabsTrigger>
                  <TabsTrigger value="labs">Labs</TabsTrigger>
                  <TabsTrigger value="history">History</TabsTrigger>
                  <TabsTrigger value="appointments">Appointments</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-4 space-y-4">
                  <Card className="bg-card">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Patient Snapshot</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4 md:grid-cols-3">
                        <SnapshotTile icon={<FileHeart className="h-4 w-4" />} label="Recent Diagnoses" value={selectedPatient.diagnoses[0]?.condition ?? "—"} />
                        <SnapshotTile icon={<ScanHeart className="h-4 w-4" />} label="Blood Pressure" value={selectedPatient.vitals.find(v => v.label === "BP")?.value ?? "—"} />
                        <SnapshotTile icon={<SearchCheck className="h-4 w-4" />} label="Next Action" value={nextActionByRisk(selectedPatient.risk)} />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-card">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Details</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Accordion type="multiple" className="w-full">
                        <AccordionItem value="conditions">
                          <AccordionTrigger>Chronic Conditions & Symptoms</AccordionTrigger>
                          <AccordionContent>
                            <div className="grid gap-3 sm:grid-cols-2">
                              <div>
                                <Label className="text-xs">Chronic Diseases</Label>
                                <div className="mt-2 flex flex-wrap gap-2">
                                  {selectedPatient.chronic.map((c) => (
                                    <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <Label className="text-xs">Symptoms</Label>
                                <div className="mt-2 flex flex-wrap gap-2">
                                  {selectedPatient.symptoms.length ? (
                                    selectedPatient.symptoms.map((s) => (
                                      <Badge key={s} className="text-xs">{s}</Badge>
                                    ))
                                  ) : (
                                    <p className="text-sm text-muted-foreground">No symptoms recorded</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="diagnoses">
                          <AccordionTrigger>Recent Diagnoses</AccordionTrigger>
                          <AccordionContent>
                            <ul className="space-y-3">
                              {selectedPatient.diagnoses.map((d, i) => (
                                <li key={`${d.condition}-${i}`} className="rounded-md border p-3">
                                  <div className="flex items-center justify-between">
                                    <p className="font-medium">{d.condition}</p>
                                    <span className="text-xs text-muted-foreground">{d.date}</span>
                                  </div>
                                  {d.notes ? <p className="mt-1 text-sm text-muted-foreground">{d.notes}</p> : null}
                                </li>
                              ))}
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="sensitive">
                          <AccordionTrigger>Sensitive Data</AccordionTrigger>
                          <AccordionContent>
                            {isUnlocked ? (
                              <div className="space-y-2">
                                <p className="text-sm">HIV Status: <span className="font-medium">{selectedPatient.sensitive?.hivStatus ?? "Unknown"}</span></p>
                                <p className="text-sm">Mental Health: <span className="font-medium">{selectedPatient.sensitive?.mentalHealthNotes ?? "—"}</span></p>
                                <div className="flex items-center gap-2">
                                  <Switch
                                    checked={isUnlocked}
                                    onCheckedChange={(v) => setIsUnlocked(v)}
                                    aria-label="Toggle sensitive data access"
                                  />
                                  <span className="text-xs text-muted-foreground">Disable to hide sensitive fields</span>
                                </div>
                              </div>
                            ) : (
                              <div className="rounded-md border bg-secondary p-3 text-sm">
                                Sensitive data is locked. Use "Unlock Sensitive" to view.
                              </div>
                            )}
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="vitals" className="mt-4">
                  <Card className="bg-card">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Vital Signs</CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                      {selectedPatient.vitals.map((v) => (
                        <div key={v.label} className="rounded-md border p-3">
                          <p className="text-sm text-muted-foreground">{v.label}</p>
                          <p className="mt-1 text-lg font-semibold">{v.value}</p>
                          <p className="text-xs text-muted-foreground">Ref: {v.range}</p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="labs" className="mt-4">
                  <Card className="bg-card">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Lab Results</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {selectedPatient.labs.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No lab results available.</p>
                      ) : (
                        <div className="grid gap-3 md:grid-cols-2">
                          {selectedPatient.labs.map((l, i) => (
                            <div key={`${l.name}-${i}`} className="rounded-md border p-3">
                              <div className="flex items-center justify-between">
                                <p className="font-medium">{l.name}</p>
                                <StatusPill status={l.status} />
                              </div>
                              <p className="mt-1 text-sm text-muted-foreground">Value: <span className="font-medium text-foreground">{l.value}{l.unit ? ` ${l.unit}` : ""}</span></p>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="history" className="mt-4">
                  <Card className="bg-card">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Medical History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-3">
                        {selectedPatient.diagnoses.map((d, i) => (
                          <li key={`${d.condition}-${i}`} className="rounded-md border p-3">
                            <div className="flex items-center justify-between">
                              <p className="font-medium">{d.condition}</p>
                              <span className="text-xs text-muted-foreground">{d.date}</span>
                            </div>
                            {d.notes ? <p className="mt-1 text-sm text-muted-foreground">{d.notes}</p> : null}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="appointments" className="mt-4">
                  <Card className="bg-card">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Appointments</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground">No upcoming appointments recorded in this demo.</p>
                      <Dialog open={isApptOpen} onOpenChange={setIsApptOpen}>
                        <DialogTrigger asChild>
                          <Button className="w-full sm:w-auto">Schedule Appointment</Button>
                        </DialogTrigger>
                        <ScheduleDialog
                          onSubmit={(dt, reason) => scheduleAppt(selectedPatient, dt, reason)}
                        />
                      </Dialog>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              <Card className="bg-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  <Button variant="secondary" className="gap-2">
                    <LayoutDashboard className="h-4 w-4" />
                    Update Vitals
                  </Button>
                  <Button variant="secondary" className="gap-2">
                    <FileHeart className="h-4 w-4" />
                    Add Diagnosis
                  </Button>
                  <Button variant="secondary" className="gap-2">
                    <ScanHeart className="h-4 w-4" />
                    Order Labs
                  </Button>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="rounded-md border bg-card p-6 text-center">
              <p className="text-sm text-muted-foreground">Select a patient to view details.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

function NavItem({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <button
      className={cn(
        "flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
        active ? "bg-sidebar-accent text-foreground" : "hover:bg-sidebar-accent"
      )}
      aria-current={active ? "page" : undefined}
    >
      <span className="text-muted-foreground">{icon}</span>
      <span className="min-w-0 truncate">{label}</span>
    </button>
  )
}

function InfoStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border p-3">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 font-medium break-words">{value}</p>
    </div>
  )
}

function SnapshotTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-md border p-3">
      <div className="flex items-center gap-2 text-muted-foreground">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <p className="mt-2 font-medium">{value}</p>
    </div>
  )
}

function nextActionByRisk(risk: RiskLevel) {
  switch (risk) {
    case "high":
      return "Intensify treatment and follow up in 1-2 weeks"
    case "medium":
      return "Monitor and follow up in 4 weeks"
    default:
      return "Routine check in 3-6 months"
  }
}

function StatusPill({ status }: { status: LabResult["status"] }) {
  const map: Record<LabResult["status"], string> = {
    normal: "bg-muted text-foreground",
    attention: "bg-accent text-accent-foreground",
    critical: "bg-destructive text-destructive-foreground",
  }
  return <span className={cn("inline-flex rounded-full px-2 py-0.5 text-xs font-medium", map[status])}>{status}</span>
}

function NewPatientForm({ onSubmit }: { onSubmit: (data: NewPatient) => void }) {
  const [firstName, setFirstName] = React.useState("")
  const [lastName, setLastName] = React.useState("")
  const [sex, setSex] = React.useState<NewPatient["sex"]>("Male")
  const [age, setAge] = React.useState<number | "">("")
  const [phone, setPhone] = React.useState("")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!firstName || !lastName || age === "" || Number(age) <= 0) {
      toast.error("Please complete required fields", { description: "First, last name and age are required." })
      return
    }
    onSubmit({ firstName, lastName, sex, age, phone })
  }

  return (
    <DialogContent className="sm:max-w-lg">
      <DialogHeader>
        <DialogTitle>New Patient Profile</DialogTitle>
        <DialogDescription>Create a new patient record with basic details.</DialogDescription>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="firstName">First Name</Label>
            <Input id="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="lastName">Last Name</Label>
            <Input id="lastName" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Sex</Label>
            <Select value={sex} onValueChange={(v) => setSex(v as NewPatient["sex"])}>
              <SelectTrigger aria-label="Sex">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Male">Male</SelectItem>
                <SelectItem value="Female">Female</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="age">Age</Label>
            <Input id="age" type="number" min={0} value={age} onChange={(e) => setAge(e.target.value === "" ? "" : Number(e.target.value))} required />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="phone">Phone (optional)</Label>
          <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+65 8xxx xxxx" />
        </div>
        <DialogFooter>
          <Button type="submit" className="w-full sm:w-auto">Create Patient</Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}

function ScheduleDialog({ onSubmit }: { onSubmit: (datetime: string, reason: string) => void }) {
  const [dt, setDt] = React.useState("")
  const [reason, setReason] = React.useState("Follow-up")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!dt) {
      toast.error("Please select a date and time")
      return
    }
    onSubmit(dt, reason)
  }

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Schedule Appointment</DialogTitle>
        <DialogDescription>Pick a time and include an optional reason.</DialogDescription>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="dt">Date & Time</Label>
          <Input id="dt" type="datetime-local" value={dt} onChange={(e) => setDt(e.target.value)} required />
        </div>
        <div className="space-y-1.5">
          <Label>Reason</Label>
          <Select value={reason} onValueChange={(v) => setReason(v)}>
            <SelectTrigger aria-label="Reason">
              <SelectValue placeholder="Select reason" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Follow-up">Follow-up</SelectItem>
              <SelectItem value="New complaint">New complaint</SelectItem>
              <SelectItem value="Medication review">Medication review</SelectItem>
              <SelectItem value="Lab review">Lab review</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <DialogFooter>
          <Button type="submit" className="w-full sm:w-auto">Confirm</Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}

function SmsDialog({ defaultPhone, onSend }: { defaultPhone: string; onSend: (phone: string, msg: string) => void }) {
  const [phone, setPhone] = React.useState(defaultPhone)
  const [msg, setMsg] = React.useState("Reminder: Please attend your follow-up appointment. Reply STOP to opt out.")

  function handleSend(e: React.FormEvent) {
    e.preventDefault()
    onSend(phone, msg)
  }

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Send SMS Alert</DialogTitle>
        <DialogDescription>Send a follow-up reminder or health advice.</DialogDescription>
      </DialogHeader>
      <form onSubmit={handleSend} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="sms-phone">Phone</Label>
          <Input id="sms-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+65 8xxx xxxx" required />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="sms-msg">Message</Label>
          <Textarea id="sms-msg" value={msg} onChange={(e) => setMsg(e.target.value)} rows={4} className="resize-none" required />
        </div>
        <DialogFooter>
          <Button type="submit" className="w-full sm:w-auto">Send SMS</Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}

function UnlockDialog({ onVerify }: { onVerify: (pin: string) => void }) {
  const [pin, setPin] = React.useState("")
  function submit(e: React.FormEvent) {
    e.preventDefault()
    onVerify(pin)
  }
  return (
    <DialogContent className="sm:max-w-sm">
      <DialogHeader>
        <DialogTitle>Unlock Sensitive Data</DialogTitle>
        <DialogDescription>Enter PIN to access sensitive patient information. This access is time-limited.</DialogDescription>
      </DialogHeader>
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="pin">PIN (demo: 1234)</Label>
          <Input id="pin" type="password" value={pin} onChange={(e) => setPin(e.target.value)} autoComplete="off" />
        </div>
        <DialogFooter>
          <Button type="submit" className="w-full sm:w-auto">Unlock</Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}