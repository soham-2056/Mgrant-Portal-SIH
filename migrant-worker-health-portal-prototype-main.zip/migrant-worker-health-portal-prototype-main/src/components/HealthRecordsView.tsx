"use client"

import React, { useEffect, useMemo, useState } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { toast } from "sonner"
import {
  TextSearch,
  ListFilter,
  FileOutput,
  FileHeart,
  Logs,
  PanelsRightBottom,
  CalendarSearch,
  ClipboardPlus,
  Biohazard,
  FunnelPlus,
  ArrowDownNarrowWide,
} from "lucide-react"

type LangKey = "en" | "hi" | "bn" | "ta"

type PersonalInfo = {
  name: string
  dob: string
  gender: string
  bloodGroup: string
  nationalId?: string
  workerId?: string
  contact?: string
  emergencyContact?: string
}

type Condition = { name: string; since: string; notes?: string }
type Allergy = { name: string; severity: "low" | "moderate" | "high"; reaction?: string }
type Vaccination = { name: string; date: string; dose?: string; location?: string }
type Vital = { date: string; bp: string; hr: number; temp: number; bmi?: number }
type Checkup = { date: string; type: string; notes?: string; vitals?: Vital }
type InfectiousStatus = { disease: string; status: "negative" | "positive" | "recovered"; lastTestDate: string; notes?: string }
type Medication = { name: string; dose: string; frequency: string; start: string; end?: string; notes?: string }
type LabReport = { id: string; name: string; date: string; type: string; summary: string; fileSizeKB: number }
type Consultation = { date: string; doctor: string; specialty: string; notes?: string; followUp?: string }
type Reminder = { id: string; title: string; date: string; type: "checkup" | "medication" | "vaccine" | "followup"; priority: "low" | "medium" | "high" }

export type HealthRecordsData = {
  personal: PersonalInfo
  conditions: Condition[]
  allergies: Allergy[]
  vaccinations: Vaccination[]
  checkups: Checkup[]
  infectious: InfectiousStatus[]
  medications: Medication[]
  labs: LabReport[]
  consultations: Consultation[]
  reminders: Reminder[]
  healthScore: number
}

const i18n: Record<
  LangKey,
  {
    title: string
    searchPlaceholder: string
    filters: { all: string; activeMeds: string; chronic: string }
    tabs: {
      personal: string
      conditions: string
      vaccinations: string
      checkups: string
      infectious: string
      medications: string
      labs: string
      consultations: string
      alerts: string
    }
    actions: {
      export: string
      print: string
      savePdf: string
      exportJson: string
      exportCsv: string
      addReminder: string
      download: string
      viewAll: string
      clearFilters: string
    }
    labels: {
      healthScore: string
      scoreExplain: string
      recommendations: string
      personalInfo: string
      dob: string
      gender: string
      bloodGroup: string
      id: string
      contact: string
      emergency: string
      conditions: string
      allergies: string
      vaccinations: string
      checkups: string
      vitals: string
      status: string
      medications: string
      labs: string
      consultations: string
      reminders: string
      none: string
    }
  }
> = {
  en: {
    title: "Health Records",
    searchPlaceholder: "Search records, doctors, labs…",
    filters: { all: "All", activeMeds: "Active medications", chronic: "Chronic only" },
    tabs: {
      personal: "Personal",
      conditions: "Conditions & Allergies",
      vaccinations: "Vaccinations",
      checkups: "Checkups & Vitals",
      infectious: "Infectious Diseases",
      medications: "Medications",
      labs: "Lab Reports",
      consultations: "Consultations",
      alerts: "Alerts & Reminders",
    },
    actions: {
      export: "Export",
      print: "Print",
      savePdf: "Save as PDF",
      exportJson: "Export JSON",
      exportCsv: "Export CSV",
      addReminder: "Add Reminder",
      download: "Download",
      viewAll: "View All",
      clearFilters: "Clear filters",
    },
    labels: {
      healthScore: "Health Score",
      scoreExplain: "Your score reflects recent vitals, chronic condition control, and appointment adherence.",
      recommendations: "Recommendations",
      personalInfo: "Personal Information",
      dob: "Date of birth",
      gender: "Gender",
      bloodGroup: "Blood group",
      id: "IDs",
      contact: "Contact",
      emergency: "Emergency",
      conditions: "Chronic Conditions",
      allergies: "Allergies",
      vaccinations: "Vaccination Records",
      checkups: "Health Checkups",
      vitals: "Vital Signs",
      status: "Status",
      medications: "Current Medications",
      labs: "Lab Reports",
      consultations: "Doctor Consultations",
      reminders: "Reminders",
      none: "No records",
    },
  },
  hi: {
    title: "स्वास्थ्य रिकॉर्ड",
    searchPlaceholder: "रिकॉर्ड, डॉक्टर, लैब खोजें…",
    filters: { all: "सभी", activeMeds: "सक्रिय दवाइयाँ", chronic: "केवल पुरानी" },
    tabs: {
      personal: "व्यक्तिगत",
      conditions: "रोग व एलर्जी",
      vaccinations: "टीकाकरण",
      checkups: "जांच व संकेत",
      infectious: "संक्रामक रोग",
      medications: "दवाइयाँ",
      labs: "लैब रिपोर्ट",
      consultations: "परामर्श",
      alerts: "अलर्ट व रिमाइंडर",
    },
    actions: {
      export: "निर्यात",
      print: "प्रिंट",
      savePdf: "PDF के रूप में सहेजें",
      exportJson: "JSON निर्यात",
      exportCsv: "CSV निर्यात",
      addReminder: "रिमाइंडर जोड़ें",
      download: "डाउनलोड",
      viewAll: "सभी देखें",
      clearFilters: "फिल्टर साफ़ करें",
    },
    labels: {
      healthScore: "स्वास्थ्य स्कोर",
      scoreExplain: "स्कोर आपके हालिया संकेत, रोग नियंत्रण और अपॉइंटमेंट पालन पर आधारित है।",
      recommendations: "सुझाव",
      personalInfo: "व्यक्तिगत जानकारी",
      dob: "जन्म तिथि",
      gender: "लिंग",
      bloodGroup: "रक्त समूह",
      id: "पहचान",
      contact: "संपर्क",
      emergency: "आपातकाल",
      conditions: "पुरानी बीमारियाँ",
      allergies: "एलर्जी",
      vaccinations: "टीकाकरण रिकॉर्ड",
      checkups: "स्वास्थ्य जांच",
      vitals: "महत्वपूर्ण संकेत",
      status: "स्थिति",
      medications: "वर्तमान दवाइयाँ",
      labs: "लैब रिपोर्ट",
      consultations: "डॉक्टर परामर्श",
      reminders: "रिमाइंडर",
      none: "कोई रिकॉर्ड नहीं",
    },
  },
  bn: {
    title: "স্বাস্থ্য রেকর্ড",
    searchPlaceholder: "রেকর্ড, ডাক্তার, ল্যাব খুঁজুন…",
    filters: { all: "সব", activeMeds: "চলতি ওষুধ", chronic: "শুধু দীর্ঘস্থায়ী" },
    tabs: {
      personal: "ব্যক্তিগত",
      conditions: "রোগ ও অ্যালার্জি",
      vaccinations: "টিকাদান",
      checkups: "পরীক্ষা ও সাইন",
      infectious: "সংক্রামক রোগ",
      medications: "ওষুধ",
      labs: "ল্যাব রিপোর্ট",
      consultations: "পরামর্শ",
      alerts: "সতর্কতা ও রিমাইন্ডার",
    },
    actions: {
      export: "রপ্তানি",
      print: "প্রিন্ট",
      savePdf: "PDF হিসেবে সংরক্ষণ",
      exportJson: "JSON রপ্তানি",
      exportCsv: "CSV রপ্তানি",
      addReminder: "রিমাইন্ডার যোগ করুন",
      download: "ডাউনলোড",
      viewAll: "সব দেখুন",
      clearFilters: "ফিল্টার মুছুন",
    },
    labels: {
      healthScore: "স্বাস্থ্য স্কোর",
      scoreExplain: "আপনার স্কোর সাম্প্রতিক সাইন, রোগ নিয়ন্ত্রণ ও অ্যাপয়েন্টমেন্ট মেনে চলা থেকে আসে।",
      recommendations: "প্রস্তাবনা",
      personalInfo: "ব্যক্তিগত তথ্য",
      dob: "জন্ম তারিখ",
      gender: "লিঙ্গ",
      bloodGroup: "রক্তের গ্রুপ",
      id: "আইডি",
      contact: "যোগাযোগ",
      emergency: "জরুরি",
      conditions: "দীর্ঘস্থায়ী রোগ",
      allergies: "অ্যালার্জি",
      vaccinations: "টিকাদান রেকর্ড",
      checkups: "স্বাস্থ্য পরীক্ষা",
      vitals: "ভাইটাল সাইন",
      status: "স্ট্যাটাস",
      medications: "বর্তমান ওষুধ",
      labs: "ল্যাব রিপোর্ট",
      consultations: "ডাক্তারের পরামর্শ",
      reminders: "রিমাইন্ডার",
      none: "কোনো রেকর্ড নেই",
    },
  },
  ta: {
    title: "ஆரோக்கியப் பதிவுகள்",
    searchPlaceholder: "பதிவுகள், மருத்துவர்கள், ஆய்வு தேடுக…",
    filters: { all: "அனைத்தும்", activeMeds: "செயலில் உள்ள மருந்துகள்", chronic: "நீடித்தவை மட்டும்" },
    tabs: {
      personal: "தனிப்பட்டது",
      conditions: "நோய்கள் & அலர்ஜி",
      vaccinations: "தடுப்பூசிகள்",
      checkups: "சோதனைகள் & அறிகுறிகள்",
      infectious: "தொற்றுநோய்கள்",
      medications: "மருந்துகள்",
      labs: "ஆய்வுக் கணக்குகள்",
      consultations: "ஆலோசனைகள்",
      alerts: "எச்சரிக்கை & நினைவூட்டல்",
    },
    actions: {
      export: "ஏற்றுமதி",
      print: "அச்சிடு",
      savePdf: "PDF ஆக சேமிக்க",
      exportJson: "JSON ஏற்றுமதி",
      exportCsv: "CSV ஏற்றுமதி",
      addReminder: "நினைவூட்டல் சேர்க்க",
      download: "பதிவிறக்கு",
      viewAll: "அனைத்தும்",
      clearFilters: "வடிகட்டலை கழிக்க",
    },
    labels: {
      healthScore: "ஆரோக்கிய மதிப்பெண்",
      scoreExplain: "சமீபத்திய சிக்னல்கள், நிலை கட்டுப்பாடு மற்றும் நேர்காணல் பின்பற்றலில் அடிப்படையாகும்.",
      recommendations: "பரிந்துரைகள்",
      personalInfo: "தனிப்பட்ட தகவல்",
      dob: "பிறந்த தேதி",
      gender: "பாலினம்",
      bloodGroup: "இரத்த வகை",
      id: "அடையாளங்கள்",
      contact: "தொடர்பு",
      emergency: "அவசரம்",
      conditions: "நீடித்த நோய்கள்",
      allergies: "அலர்ஜிகள்",
      vaccinations: "தடுப்பூசி பதிவுகள்",
      checkups: "சோதனைகள்",
      vitals: "அத்தியாவசிய அளவுகள்",
      status: "நிலை",
      medications: "தற்போதைய மருந்துகள்",
      labs: "ஆய்வு அறிக்கைகள்",
      consultations: "மருத்துவர் ஆலோசனைகள்",
      reminders: "நினைவூட்டல்கள்",
      none: "பதிவுகள் இல்லை",
    },
  },
}

export interface HealthRecordsViewProps {
  data?: HealthRecordsData
  defaultLanguage?: LangKey
  className?: string
}

const defaultData: HealthRecordsData = {
  personal: {
    name: "Ravi Kumar",
    dob: "1990-07-14",
    gender: "Male",
    bloodGroup: "B+",
    nationalId: "IN-5678-9932",
    workerId: "MW-2025-00123",
    contact: "+91 98765 43210",
    emergencyContact: "Sita Devi (+91 98765 11111)",
  },
  conditions: [
    { name: "Hypertension", since: "2018-05-01", notes: "Lifestyle modifications ongoing" },
    { name: "Type 2 Diabetes", since: "2020-11-12", notes: "On Metformin; A1C trending down" },
  ],
  allergies: [
    { name: "Penicillin", severity: "high", reaction: "Rash and swelling" },
    { name: "Peanuts", severity: "moderate", reaction: "Hives" },
  ],
  vaccinations: [
    { name: "Tetanus (Td)", date: "2022-02-10", dose: "Booster", location: "Chennai PHC" },
    { name: "Hepatitis B", date: "2021-07-22", dose: "Dose 3", location: "Apollo Clinic" },
    { name: "COVID-19", date: "2023-09-05", dose: "Booster", location: "Govt Hospital" },
  ],
  checkups: [
    {
      date: "2025-08-28",
      type: "Annual Physical",
      notes: "Encouraged 30min walk daily",
      vitals: { date: "2025-08-28", bp: "122/78", hr: 72, temp: 36.7, bmi: 23.4 },
    },
    {
      date: "2025-05-10",
      type: "Diabetes Review",
      notes: "A1C 6.8%",
      vitals: { date: "2025-05-10", bp: "126/82", hr: 74, temp: 36.8, bmi: 23.8 },
    },
  ],
  infectious: [
    { disease: "Tuberculosis", status: "negative", lastTestDate: "2025-06-02", notes: "IGRA negative" },
    { disease: "Hepatitis C", status: "negative", lastTestDate: "2025-01-16" },
    { disease: "COVID-19", status: "recovered", lastTestDate: "2023-06-11", notes: "Recovered, vaccinated" },
  ],
  medications: [
    { name: "Metformin", dose: "500mg", frequency: "BID", start: "2021-11-12" },
    { name: "Amlodipine", dose: "5mg", frequency: "OD", start: "2019-05-01" },
  ],
  labs: [
    { id: "LR-001", name: "Complete Blood Count", date: "2025-08-28", type: "Blood", summary: "All indices within range", fileSizeKB: 84 },
    { id: "LR-002", name: "A1C", date: "2025-05-10", type: "Blood", summary: "6.8% - improving", fileSizeKB: 32 },
    { id: "LR-003", name: "Chest X-ray", date: "2025-06-02", type: "Imaging", summary: "Clear lungs", fileSizeKB: 256 },
  ],
  consultations: [
    { date: "2025-08-28", doctor: "Dr. Meera Singh", specialty: "General Medicine", notes: "Lifestyle advice", followUp: "2026-08-28" },
    { date: "2025-05-10", doctor: "Dr. Raj Patel", specialty: "Endocrinology", notes: "Titrate dosage", followUp: "2025-08-10" },
  ],
  reminders: [
    { id: "RM-1", title: "Take Metformin", date: "2025-09-15 08:00", type: "medication", priority: "high" },
    { id: "RM-2", title: "Annual Dental Check", date: "2025-11-01 10:00", type: "checkup", priority: "medium" },
    { id: "RM-3", title: "HepB Antibody Titer", date: "2026-01-12 09:30", type: "vaccine", priority: "low" },
  ],
  healthScore: 78,
}

function cx(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ")
}

function formatDate(str?: string) {
  if (!str) return ""
  const d = new Date(str)
  if (isNaN(d.getTime())) return str
  return d.toLocaleDateString()
}

export default function HealthRecordsView({
  data: incoming,
  defaultLanguage = "en",
  className,
}: HealthRecordsViewProps) {
  const [lang, setLang] = useState<LangKey>(defaultLanguage)
  const t = i18n[lang]
  const data = incoming ?? defaultData

  const [query, setQuery] = useState("")
  const [filter, setFilter] = useState<"all" | "activeMeds" | "chronic">("all")

  // Debounced query for performance
  const [debounced, setDebounced] = useState("")
  useEffect(() => {
    const id = setTimeout(() => setDebounced(query.trim().toLowerCase()), 250)
    return () => clearTimeout(id)
  }, [query])

  const filtered = useMemo(() => {
    const q = debounced
    const includesQ = (s?: string) => (q ? (s ?? "").toLowerCase().includes(q) : true)
    const result: HealthRecordsData = {
      ...data,
      conditions:
        filter === "chronic" || filter === "all"
          ? data.conditions.filter((c) => includesQ(c.name) || includesQ(c.notes) || includesQ(c.since))
          : data.conditions,
      allergies: data.allergies.filter((a) => includesQ(a.name) || includesQ(a.reaction)),
      vaccinations: data.vaccinations.filter((v) => includesQ(v.name) || includesQ(v.location) || includesQ(v.date) || includesQ(v.dose)),
      checkups: data.checkups.filter((c) => includesQ(c.type) || includesQ(c.notes) || includesQ(c.date)),
      infectious: data.infectious.filter((i) => includesQ(i.disease) || includesQ(i.status) || includesQ(i.notes) || includesQ(i.lastTestDate)),
      medications:
        filter === "activeMeds" || filter === "all"
          ? data.medications.filter((m) => includesQ(m.name) || includesQ(m.dose) || includesQ(m.frequency))
          : data.medications,
      labs: data.labs.filter((l) => includesQ(l.name) || includesQ(l.type) || includesQ(l.summary) || includesQ(l.date)),
      consultations: data.consultations.filter((c) => includesQ(c.doctor) || includesQ(c.specialty) || includesQ(c.notes) || includesQ(c.date)),
      reminders: data.reminders.filter((r) => includesQ(r.title) || includesQ(r.type) || includesQ(r.date)),
      personal: data.personal,
      healthScore: data.healthScore,
    }
    return result
  }, [data, debounced, filter])

  // Export helpers (client-only, run on interaction)
  const handlePrint = () => {
    if (typeof window === "undefined") return
    window.print()
  }

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  }

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: "application/json" })
    downloadBlob(blob, "health-records.json")
    toast.success("JSON exported")
  }

  const exportCSV = () => {
    // Minimal CSV of labs for demo; can be extended
    const header = ["id", "name", "date", "type", "summary"]
    const rows = filtered.labs.map((l) => [l.id, l.name, l.date, l.type, l.summary.replace(/[\n\r,]/g, " ")])
    const csv = [header.join(","), ...rows.map((r) => r.map((v) => `"${v}"`).join(","))].join("\n")
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" })
    downloadBlob(blob, "lab-reports.csv")
    toast.success("CSV exported")
  }

  const exportPDF = () => {
    // Guiding users to "Save as PDF" through print dialog (reliable cross-browser)
    handlePrint()
    toast.message("Tip", { description: "Use your browser's Print dialog to Save as PDF." })
  }

  const downloadLab = (r: LabReport) => {
    const content = `Lab Report: ${r.name}\nDate: ${r.date}\nType: ${r.type}\nSummary: ${r.summary}\n`
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" })
    downloadBlob(blob, `${r.id}-${r.name.replace(/\s+/g, "_")}.txt`)
    toast.success("Downloading report…")
  }

  const addReminder = () => {
    toast.success("Reminder scheduled", { description: "We will remind you at the selected time." })
  }

  // Health recommendations based on score (simple rules)
  const recs = useMemo(() => {
    const s = data.healthScore
    const list: string[] = []
    if (s < 60) list.push("Schedule a comprehensive checkup within 2 weeks.")
    if (s < 80) list.push("Aim for 30 minutes of brisk walking daily.")
    if (s < 90) list.push("Track blood pressure twice a week and reduce salt intake.")
    list.push("Keep vaccinations up to date and follow doctor’s advice.")
    return list
  }, [data.healthScore])

  return (
    <Card className={cx("w-full max-w-full bg-card border rounded-2xl shadow-sm", className)}>
      <CardHeader className="space-y-1">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <PanelsRightBottom className="h-5 w-5 text-primary" aria-hidden="true" />
            <CardTitle className="text-xl sm:text-2xl">{t.title}</CardTitle>
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="secondary" size="sm" onClick={exportPDF} aria-label={t.actions.savePdf}>
                    <FileOutput className="mr-2 h-4 w-4" />
                    {t.actions.savePdf}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Opens print dialog to save as PDF</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Button variant="secondary" size="sm" onClick={exportJSON} aria-label={t.actions.exportJson}>
              <Logs className="mr-2 h-4 w-4" />
              {t.actions.exportJson}
            </Button>
            <Button variant="secondary" size="sm" onClick={exportCSV} aria-label={t.actions.exportCsv}>
              <ArrowDownNarrowWide className="mr-2 h-4 w-4" />
              {t.actions.exportCsv}
            </Button>
            <Button variant="default" size="sm" onClick={handlePrint} aria-label={t.actions.print}>
              <FileHeart className="mr-2 h-4 w-4" />
              {t.actions.print}
            </Button>
          </div>
        </div>

        {/* Controls */}
        <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative min-w-0 flex-1">
            <TextSearch className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              aria-label={t.searchPlaceholder}
              className="pl-9 bg-secondary/60"
            />
          </div>
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={(v: "all" | "activeMeds" | "chronic") => setFilter(v)}>
              <SelectTrigger className="w-[180px] bg-secondary/60" aria-label="Filter">
                <ListFilter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder={t.actions.viewAll} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t.filters.all}</SelectItem>
                <SelectItem value="activeMeds">{t.filters.activeMeds}</SelectItem>
                <SelectItem value="chronic">{t.filters.chronic}</SelectItem>
              </SelectContent>
            </Select>

            <Select value={lang} onValueChange={(v: LangKey) => setLang(v)}>
              <SelectTrigger className="w-[150px] bg-secondary/60" aria-label="Language">
                <FunnelPlus className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="hi">हिंदी</SelectItem>
                <SelectItem value="bn">বাংলা</SelectItem>
                <SelectItem value="ta">தமிழ்</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="ghost" size="sm" onClick={() => { setFilter("all"); setQuery(""); }} aria-label={t.actions.clearFilters}>
              <CalendarSearch className="mr-2 h-4 w-4" />
              {t.actions.clearFilters}
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Health Score */}
        <Card className="bg-secondary">
          <CardContent className="pt-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="min-w-[180px]">
                <Label className="text-sm text-muted-foreground">{t.labels.healthScore}</Label>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-primary">{data.healthScore}</span>
                  <span className="text-sm text-muted-foreground">/ 100</span>
                </div>
                <Progress value={data.healthScore} className="mt-3" />
              </div>
              <Separator orientation="vertical" className="hidden h-16 sm:block" />
              <div className="min-w-0 flex-1">
                <p className="text-sm text-muted-foreground">{t.labels.scoreExplain}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {recs.map((r, i) => (
                    <Badge key={i} variant="secondary" className="bg-accent text-accent-foreground">
                      {r}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-5">
            <TabsTrigger value="personal">{t.tabs.personal}</TabsTrigger>
            <TabsTrigger value="conditions">{t.tabs.conditions}</TabsTrigger>
            <TabsTrigger value="vaccinations">{t.tabs.vaccinations}</TabsTrigger>
            <TabsTrigger value="checkups">{t.tabs.checkups}</TabsTrigger>
            <TabsTrigger value="infectious">{t.tabs.infectious}</TabsTrigger>
          </TabsList>

          <TabsContent value="personal" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.personalInfo}</CardTitle>
                <CardDescription className="break-words">{filtered.personal.name}</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4 sm:grid-cols-2">
                <InfoRow label={t.labels.dob} value={formatDate(filtered.personal.dob)} />
                <InfoRow label={t.labels.gender} value={filtered.personal.gender} />
                <InfoRow label={t.labels.bloodGroup} value={filtered.personal.bloodGroup} />
                <InfoRow label={t.labels.id} value={`${filtered.personal.workerId ?? ""} ${filtered.personal.nationalId ? "• " + filtered.personal.nationalId : ""}`} />
                <InfoRow label={t.labels.contact} value={filtered.personal.contact ?? ""} />
                <InfoRow label={t.labels.emergency} value={filtered.personal.emergencyContact ?? ""} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="conditions" className="mt-4">
            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">{t.labels.conditions}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {filtered.conditions.length === 0 && <EmptyState label={t.labels.none} />}
                    {filtered.conditions.map((c, i) => (
                      <AccordionItem key={i} value={`cond-${i}`} className="border-b">
                        <AccordionTrigger className="text-left">
                          <div className="flex w-full items-center justify-between gap-3">
                            <span className="min-w-0 truncate">{c.name}</span>
                            <Badge variant="outline">{formatDate(c.since)}</Badge>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          <p className="text-sm text-muted-foreground break-words">{c.notes ?? ""}</p>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">{t.labels.allergies}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {filtered.allergies.length === 0 && <EmptyState label={t.labels.none} />}
                    {filtered.allergies.map((a, i) => (
                      <div key={i} className="flex items-start justify-between rounded-md border bg-card p-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{a.name}</span>
                            <SeverityBadge severity={a.severity} />
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground break-words">{a.reaction ?? ""}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="vaccinations" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.vaccinations}</CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="multiple" className="w-full">
                  {filtered.vaccinations.length === 0 && <EmptyState label={t.labels.none} />}
                  {filtered.vaccinations.map((v, i) => (
                    <AccordionItem key={i} value={`vac-${i}`} className="border-b">
                      <AccordionTrigger className="text-left">
                        <div className="flex w-full items-center justify-between gap-3">
                          <span className="min-w-0 truncate">{v.name}</span>
                          <div className="flex items-center gap-2">
                            {v.dose && <Badge variant="secondary" className="bg-accent text-accent-foreground">{v.dose}</Badge>}
                            <Badge variant="outline">{formatDate(v.date)}</Badge>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-muted-foreground">{v.location ?? ""}</p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="checkups" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.checkups}</CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible>
                  {filtered.checkups.length === 0 && <EmptyState label={t.labels.none} />}
                  {filtered.checkups.map((c, i) => (
                    <AccordionItem key={i} value={`chk-${i}`} className="border-b">
                      <AccordionTrigger className="text-left">
                        <div className="flex w-full items-center justify-between gap-3">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-medium">{c.type}</span>
                              <Badge variant="outline">{formatDate(c.date)}</Badge>
                            </div>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="grid gap-3 sm:grid-cols-2">
                          <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">{t.labels.vitals}</Label>
                            <div className="flex flex-wrap gap-2">
                              {c.vitals ? (
                                <>
                                  <VitalsChip label="BP" value={c.vitals.bp} />
                                  <VitalsChip label="HR" value={`${c.vitals.hr} bpm`} />
                                  <VitalsChip label="Temp" value={`${c.vitals.temp} °C`} />
                                  {"bmi" in c.vitals && c.vitals.bmi !== undefined ? <VitalsChip label="BMI" value={`${c.vitals.bmi}`} /> : null}
                                </>
                              ) : (
                                <span className="text-sm text-muted-foreground">{t.labels.none}</span>
                              )}
                            </div>
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">Notes</Label>
                            <p className="text-sm text-muted-foreground break-words">{c.notes ?? ""}</p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="infectious" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.status}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {filtered.infectious.length === 0 && <EmptyState label={t.labels.none} />}
                {filtered.infectious.map((i, idx) => (
                  <div key={idx} className="flex items-start justify-between rounded-md border bg-card p-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Biohazard className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                        <span className="font-medium">{i.disease}</span>
                        <Badge
                          variant="secondary"
                          className={cx(
                            "capitalize",
                            i.status === "positive" && "bg-destructive text-destructive-foreground",
                            i.status === "recovered" && "bg-accent text-accent-foreground",
                          )}
                        >
                          {i.status}
                        </Badge>
                        <Badge variant="outline">{formatDate(i.lastTestDate)}</Badge>
                      </div>
                      {i.notes && <p className="mt-1 text-sm text-muted-foreground break-words">{i.notes}</p>}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Second row of tabs for remaining sections */}
        <Tabs defaultValue="medications" className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3">
            <TabsTrigger value="medications">{t.tabs.medications}</TabsTrigger>
            <TabsTrigger value="labs">{t.tabs.labs}</TabsTrigger>
            <TabsTrigger value="consultations">{t.tabs.consultations}</TabsTrigger>
          </TabsList>

          <TabsContent value="medications" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.medications}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {filtered.medications.length === 0 && <EmptyState label={t.labels.none} />}
                {filtered.medications.map((m, i) => (
                  <div key={i} className="flex items-start justify-between rounded-md border bg-card p-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium">{m.name}</span>
                        <Badge variant="outline">{m.dose}</Badge>
                        <Badge variant="secondary" className="bg-accent text-accent-foreground">
                          {m.frequency}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{formatDate(m.start)}</span>
                      </div>
                      {m.notes && <p className="mt-1 text-sm text-muted-foreground break-words">{m.notes}</p>}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="labs" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.labs}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {filtered.labs.length === 0 && <EmptyState label={t.labels.none} />}
                {filtered.labs.map((r) => (
                  <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-md border bg-card p-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium min-w-0 truncate">{r.name}</span>
                        <Badge variant="outline">{r.type}</Badge>
                        <Badge variant="secondary" className="bg-accent text-accent-foreground">
                          {formatDate(r.date)}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{r.fileSizeKB} KB</span>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground break-words">{r.summary}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="secondary" size="sm" onClick={() => downloadLab(r)} aria-label={`${t.actions.download} ${r.name}`}>
                        <ClipboardPlus className="mr-2 h-4 w-4" />
                        {t.actions.download}
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="consultations" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t.labels.consultations}</CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible>
                  {filtered.consultations.length === 0 && <EmptyState label={t.labels.none} />}
                  {filtered.consultations.map((c, i) => (
                    <AccordionItem key={i} value={`con-${i}`} className="border-b">
                      <AccordionTrigger className="text-left">
                        <div className="flex w-full items-center justify-between gap-3">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-medium">{c.doctor}</span>
                              <Badge variant="outline">{c.specialty}</Badge>
                              <Badge variant="secondary" className="bg-accent text-accent-foreground">
                                {formatDate(c.date)}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="grid gap-3 sm:grid-cols-2">
                          <div>
                            <Label className="text-xs text-muted-foreground">Notes</Label>
                            <p className="mt-1 text-sm text-muted-foreground break-words">{c.notes ?? ""}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-muted-foreground">Follow-up</Label>
                            <p className="mt-1 text-sm text-muted-foreground">{c.followUp ? formatDate(c.followUp) : t.labels.none}</p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Alerts & Reminders */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">{t.tabs.alerts}</CardTitle>
              <CardDescription>{t.labels.reminders}</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" size="sm" onClick={addReminder}>
                <CalendarSearch className="mr-2 h-4 w-4" />
                {t.actions.addReminder}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {filtered.reminders.length === 0 && <EmptyState label={t.labels.none} />}
            {filtered.reminders.map((r) => (
              <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-md border bg-card p-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{r.title}</span>
                    <Badge variant="outline" className="capitalize">{r.type}</Badge>
                    <Badge
                      variant="secondary"
                      className={cx(
                        "capitalize",
                        r.priority === "high" && "bg-destructive text-destructive-foreground",
                        r.priority === "medium" && "bg-accent text-accent-foreground",
                      )}
                    >
                      {r.priority}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{r.date}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" aria-label="Snooze">
                    <ClockIcon className="h-4 w-4 text-muted-foreground" />
                  </Button>
                  <Button variant="ghost" size="icon" aria-label="Options">
                    <OptionsIcon className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  )
}

/* Sub-components */

function InfoRow({ label, value }: { label: string; value?: string }) {
  return (
    <div className="min-w-0">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <p className="mt-1 break-words">{value || "-"}</p>
    </div>
  )
}

function SeverityBadge({ severity }: { severity: "low" | "moderate" | "high" }) {
  const cls =
    severity === "high"
      ? "bg-destructive text-destructive-foreground"
      : severity === "moderate"
      ? "bg-accent text-accent-foreground"
      : "bg-secondary text-secondary-foreground"
  return (
    <Badge variant="secondary" className={cls}>
      {severity}
    </Badge>
  )
}

function VitalsChip({ label, value }: { label: string; value: string }) {
  return (
    <span className="inline-flex items-center rounded-md bg-secondary px-2 py-1 text-xs text-secondary-foreground">
      <span className="mr-1 font-medium">{label}:</span> {value}
    </span>
  )
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="flex items-center justify-center rounded-md border border-dashed bg-muted/40 p-6 text-sm text-muted-foreground">
      {label}
    </div>
  )
}

/**
 * Minimal inline icons built with available lucide icons to keep a cohesive look
 * Composed icons use allowed icons; fallbacks ensure no external dependencies.
 */
function ClockIcon(props: React.SVGProps<SVGSVGElement>) {
  // Using CalendarSearch as a subtle clock/schedule metaphor
  return <CalendarSearch {...props} />
}
function OptionsIcon(props: React.SVGProps<SVGSVGElement>) {
  // Using ArrowDownNarrowWide as a generic options metaphor
  return <ArrowDownNarrowWide {...props} />
}