"use client";

import React, { useMemo, useState } from "react";
import {
  LayoutDashboard,
  Hospital,
  ChartPie,
  ChartNoAxesCombined,
  ChartColumnStacked,
  ChartSpline,
  ChartBarBig,
  ChartScatter,
  ChartArea,
  Logs,
  FileChartLine,
  Radar,
  ChartColumn,
  ScanHeart,
  SquareActivity,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";

type AdminRole = "state" | "district" | "hospital";

type FilterState = {
  roleScope: AdminRole;
  state?: string;
  district?: string;
  hospitalId?: string;
  dateFrom?: string;
  dateTo?: string;
};

type WidgetConfig = {
  id: string;
  title: string;
  enabled: boolean;
};

export interface GovernmentAdminDashboardProps {
  className?: string;
  role: AdminRole;
  initialFilters?: Partial<FilterState>;
  initialWidgets?: WidgetConfig[];
  onFiltersChange?: (filters: FilterState) => void;
  style?: React.CSSProperties;
}

const defaultWidgets: WidgetConfig[] = [
  { id: "registered-workers", title: "Registered Workers", enabled: true },
  { id: "vaccination-coverage", title: "Vaccination Coverage", enabled: true },
  { id: "disease-trends", title: "Disease Incidence", enabled: true },
  { id: "hospital-usage", title: "Hospital Usage", enabled: true },
  { id: "demographics", title: "Demographic Health Trends", enabled: true },
  { id: "ai-surveillance", title: "AI Surveillance Alerts", enabled: true },
  { id: "scheme-enrollment", title: "Scheme Enrollment", enabled: true },
  { id: "employer-compliance", title: "Employer Compliance", enabled: true },
  { id: "health-score", title: "Health Score Distribution", enabled: true },
  { id: "qr-usage", title: "QR Code Usage", enabled: true },
];

function toCSV(rows: Record<string, string | number>[]): string {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const headerLine = headers.join(",");
  const lines = rows.map((r) =>
    headers
      .map((h) => {
        const v = String(r[h] ?? "");
        if (v.includes(",") || v.includes('"') || v.includes("\n")) {
          return `"${v.replace(/"/g, '""')}"`;
        }
        return v;
      })
      .join(",")
  );
  return [headerLine, ...lines].join("\n");
}

function download(filename: string, content: string, type = "text/csv;charset=utf-8") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  URL.revokeObjectURL(url);
  a.remove();
}

function SectionHeader({
  icon,
  title,
  description,
  actions,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex w-full items-start justify-between gap-3">
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          {icon}
          <h2 className="text-lg sm:text-xl font-semibold leading-tight truncate">{title}</h2>
        </div>
        {description ? (
          <p className="text-sm text-muted-foreground mt-1 break-words">{description}</p>
        ) : null}
      </div>
      {actions ? <div className="shrink-0">{actions}</div> : null}
    </div>
  );
}

function MiniSparkline({
  values,
  color = "var(--chart-1)",
  ariaLabel,
}: {
  values: number[];
  color?: string;
  ariaLabel?: string;
}) {
  const w = 160;
  const h = 44;
  const max = Math.max(...values, 1);
  const points = values
    .map((v, i) => {
      const x = (i / (values.length - 1 || 1)) * (w - 6) + 3;
      const y = h - 6 - (v / max) * (h - 12) + 3;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <svg
      width={w}
      height={h}
      role="img"
      aria-label={ariaLabel}
      className="block overflow-visible"
    >
      <title>{ariaLabel}</title>
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  );
}

function MiniBar({
  values,
  ariaLabel,
  colors,
}: {
  values: number[];
  ariaLabel?: string;
  colors?: string[];
}) {
  const max = Math.max(...values, 1);
  return (
    <div aria-label={ariaLabel} className="flex items-end gap-1 h-16">
      {values.map((v, i) => {
        const height = (v / max) * 64 + 4;
        const clr = colors?.[i % (colors?.length || 1)] || "var(--chart-3)";
        return (
          <div
            key={i}
            className="w-2 rounded-sm"
            style={{ height: `${height}px`, backgroundColor: clr }}
            aria-hidden
          />
        );
      })}
    </div>
  );
}

function Donut({
  percent,
  label,
  ariaLabel,
  color = "var(--chart-4)",
}: {
  percent: number;
  label?: string;
  ariaLabel?: string;
  color?: string;
}) {
  const size = 120;
  const stroke = 12;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.min(Math.max(percent, 0), 100) / 100);

  return (
    <div className="relative" role="img" aria-label={ariaLabel}>
      <svg width={size} height={size} className="block">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="var(--muted)"
          strokeWidth={stroke}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-500 ease-out"
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="text-xl font-semibold">{percent}%</div>
          {label ? <div className="text-xs text-muted-foreground">{label}</div> : null}
        </div>
      </div>
    </div>
  );
}

export default function GovernmentAdminDashboard({
  className,
  role,
  initialFilters,
  initialWidgets,
  onFiltersChange,
  style,
}: GovernmentAdminDashboardProps) {
  const [filters, setFilters] = useState<FilterState>({
    roleScope: role,
    state: initialFilters?.state,
    district: initialFilters?.district,
    hospitalId: initialFilters?.hospitalId,
    dateFrom: initialFilters?.dateFrom ?? "",
    dateTo: initialFilters?.dateTo ?? "",
  });
  const [widgets, setWidgets] = useState<WidgetConfig[]>(
    initialWidgets?.length ? initialWidgets : defaultWidgets
  );
  const [onlyAnonymized, setOnlyAnonymized] = useState(true);
  const [gdprConsent, setGdprConsent] = useState(true);

  function updateFilters(next: Partial<FilterState>) {
    const merged = { ...filters, ...next };
    setFilters(merged);
    onFiltersChange?.(merged);
  }

  const summary = useMemo(() => {
    // Mocked derived numbers based on role (for demo and layout)
    const scopeFactor = role === "state" ? 1 : role === "district" ? 0.55 : 0.18;
    const workers = Math.round(240000 * scopeFactor);
    const vaccinatedPct = Math.round(74 + 6 * scopeFactor);
    const hospitals = role === "hospital" ? 1 : role === "district" ? 22 : 180;
    const alerts = role === "hospital" ? 3 : role === "district" ? 8 : 21;
    return { workers, vaccinatedPct, hospitals, alerts };
  }, [role]);

  function handleExportCSV() {
    const rows = [
      {
        metric: "registered_workers",
        value: summary.workers,
        state: filters.state || "all",
        district: filters.district || "all",
        hospital: filters.hospitalId || "all",
        from: filters.dateFrom || "any",
        to: filters.dateTo || "any",
        anonymized: onlyAnonymized ? "yes" : "no",
      },
      {
        metric: "vaccination_coverage_pct",
        value: summary.vaccinatedPct,
        state: filters.state || "all",
        district: filters.district || "all",
        hospital: filters.hospitalId || "all",
        from: filters.dateFrom || "any",
        to: filters.dateTo || "any",
        anonymized: onlyAnonymized ? "yes" : "no",
      },
    ];
    const csv = toCSV(rows);
    download(`dashboard_export_${Date.now()}.csv`, csv);
    toast.success("Export started", {
      description: "Your CSV download has begun.",
    });
  }

  function handleAnonymizeToggle(checked: boolean) {
    setOnlyAnonymized(checked);
    toast.message(checked ? "Anonymization enabled" : "Anonymization disabled", {
      description: checked
        ? "All exports and drill-downs will exclude personal identifiers."
        : "Drill-downs may include personal identifiers per access policy.",
    });
  }

  function handleWidgetToggle(id: string, enabled: boolean) {
    setWidgets((prev) => prev.map((w) => (w.id === id ? { ...w, enabled } : w)));
  }

  const enabled = (id: string) => widgets.find((w) => w.id === id)?.enabled !== false;

  return (
    <section
      className={cn(
        "w-full max-w-full bg-card/80 backdrop-blur-sm rounded-lg border shadow-sm",
        "p-4 sm:p-6 md:p-8",
        className
      )}
      style={style}
      aria-label="Government Admin Analytics Dashboard"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="h-5 w-5 text-primary" aria-hidden />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold leading-tight truncate">
              Government Analytics
            </h1>
          </div>
          <p className="text-sm text-muted-foreground mt-1 break-words">
            Role: {role.charAt(0).toUpperCase() + role.slice(1)} admin · Real-time insights for
            policy, planning, and compliance.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="secondary" className="bg-secondary hover:bg-accent">
                <SquareActivity className="mr-2 h-4 w-4" />
                Configure
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Customize Dashboard</DialogTitle>
                <DialogDescription>
                  Toggle widgets to tailor your analytics view. Changes are saved locally.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                {widgets.map((w) => (
                  <div key={w.id} className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{w.title}</p>
                      <p className="text-sm text-muted-foreground">
                        ID: <span className="break-words">{w.id}</span>
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={w.enabled}
                        onCheckedChange={(c) => handleWidgetToggle(w.id, c)}
                        aria-label={`Toggle ${w.title}`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <FileChartLine className="mr-2 h-4 w-4" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>Export data</DropdownMenuLabel>
              <DropdownMenuItem onClick={handleExportCSV}>CSV (current view)</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() =>
                  toast.info("Scheduled export", {
                    description: "Daily export at 06:00 configured.",
                  })
                }
              >
                Schedule daily
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Separator className="my-4" />

      <div className="grid gap-3 sm:gap-4 md:gap-6">
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <ChartNoAxesCombined className="h-4 w-4 text-primary" />
              Filters
            </CardTitle>
            <CardDescription>
              Narrow down analytics by scope and timeframe. All charts respond instantly.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
            <div className="space-y-2">
              <Label htmlFor="state">State</Label>
              <Select
                value={filters.state}
                onValueChange={(v) => updateFilters({ state: v })}
              >
                <SelectTrigger id="state" aria-label="Filter by state">
                  <SelectValue placeholder="All states" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All</SelectItem>
                  <SelectItem value="KA">Karnataka</SelectItem>
                  <SelectItem value="MH">Maharashtra</SelectItem>
                  <SelectItem value="GJ">Gujarat</SelectItem>
                  <SelectItem value="DL">Delhi</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="district">District</Label>
              <Select
                value={filters.district}
                onValueChange={(v) => updateFilters({ district: v })}
              >
                <SelectTrigger id="district" aria-label="Filter by district">
                  <SelectValue placeholder="All districts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All</SelectItem>
                  <SelectItem value="BLR">Bengaluru</SelectItem>
                  <SelectItem value="PNE">Pune</SelectItem>
                  <SelectItem value="AHD">Ahmedabad</SelectItem>
                  <SelectItem value="NDL">New Delhi</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="hospital">Hospital</Label>
              <Select
                value={filters.hospitalId}
                onValueChange={(v) => updateFilters({ hospitalId: v })}
              >
                <SelectTrigger id="hospital" aria-label="Filter by hospital">
                  <SelectValue placeholder="All hospitals" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All</SelectItem>
                  <SelectItem value="HSP-001">City General</SelectItem>
                  <SelectItem value="HSP-002">Metro Care</SelectItem>
                  <SelectItem value="HSP-003">Sunrise Health</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="from">From</Label>
              <Input
                id="from"
                type="date"
                value={filters.dateFrom}
                onChange={(e) => updateFilters({ dateFrom: e.target.value })}
                className="bg-card"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="to">To</Label>
              <Input
                id="to"
                type="date"
                value={filters.dateTo}
                onChange={(e) => updateFilters({ dateTo: e.target.value })}
                className="bg-card"
              />
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <ScanHeart className="h-4 w-4 text-primary" />
                Privacy mode
              </Label>
              <div className="flex items-center justify-between rounded-md border bg-secondary px-3 py-2">
                <span className="text-sm text-muted-foreground">Anonymize data</span>
                <Switch checked={onlyAnonymized} onCheckedChange={handleAnonymizeToggle} />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <Card className="bg-card">
            <CardHeader className="pb-2">
              <CardDescription>Registered workers</CardDescription>
              <CardTitle className="text-2xl">{summary.workers.toLocaleString()}</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <MiniSparkline
                values={[10, 12, 14, 15, 18, 20, 22, 24, 30, 28, 32]}
                color="var(--chart-1)"
                ariaLabel="Registered workers trend"
              />
              <Badge variant="secondary" className="bg-accent text-primary">
                +4.2% m/m
              </Badge>
            </CardContent>
          </Card>

          <Card className="bg-card">
            <CardHeader className="pb-2">
              <CardDescription>Vaccination coverage</CardDescription>
              <CardTitle className="text-2xl">{summary.vaccinatedPct}%</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <MiniBar
                values={[65, 67, 70, 72, 73, 75, 78]}
                ariaLabel="Vaccination weekly coverage"
                colors={["var(--chart-2)"]}
              />
              <Badge variant="outline">Target 85%</Badge>
            </CardContent>
          </Card>

          <Card className="bg-card">
            <CardHeader className="pb-2">
              <CardDescription>Hospitals in scope</CardDescription>
              <CardTitle className="text-2xl">{summary.hospitals}</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <Hospital className="h-8 w-8 text-primary" />
              <Badge variant="secondary" className="bg-secondary">Active</Badge>
            </CardContent>
          </Card>

          <Card className="bg-card">
            <CardHeader className="pb-2">
              <CardDescription>Active alerts</CardDescription>
              <CardTitle className="text-2xl">{summary.alerts}</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <Radar className="h-8 w-8 text-destructive" />
              <Badge variant="destructive">Review</Badge>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="surveillance">Surveillance</TabsTrigger>
            <TabsTrigger value="compliance">Compliance</TabsTrigger>
            <TabsTrigger value="gdpr">GDPR</TabsTrigger>
            <TabsTrigger value="logs">Audit Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 pt-4">
            {enabled("registered-workers") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartColumn className="h-4 w-4 text-primary" />}
                    title="Registered Worker Counts"
                    description="Monthly registered worker counts by region with drill-down."
                    actions={
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">Drill down</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Worker Registrations - Breakdown</DialogTitle>
                            <DialogDescription>
                              View by state, district, and hospital facility.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="rounded-md border p-4">
                              <h4 className="font-medium mb-2">Top Districts</h4>
                              <div className="space-y-2">
                                {["Bengaluru", "Pune", "Ahmedabad", "New Delhi"].map((d, i) => (
                                  <div key={d} className="flex items-center gap-3">
                                    <div
                                      className="h-2 rounded bg-chart-1"
                                      style={{ width: `${80 - i * 15}%` }}
                                      aria-hidden
                                    />
                                    <span className="text-sm min-w-0 truncate">{d}</span>
                                    <span className="ml-auto text-sm text-muted-foreground">
                                      {Math.round(4200 - i * 650)}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                            <div className="rounded-md border p-4">
                              <h4 className="font-medium mb-2">Trend</h4>
                              <MiniSparkline
                                values={[12, 14, 15, 17, 16, 20, 21, 22, 25, 26, 28, 30]}
                                color="var(--chart-1)"
                                ariaLabel="Registration monthly trend"
                              />
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    }
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm text-muted-foreground">Last 12 months</p>
                      <Badge variant="outline">Auto-refresh</Badge>
                    </div>
                    <div className="flex items-end gap-2 h-40">
                      {[18, 20, 22, 20, 24, 27, 28, 30, 29, 31, 34, 36].map((v, i) => (
                        <div
                          key={i}
                          className="w-4 rounded bg-chart-1"
                          style={{ height: `${v * 4}px` }}
                          aria-hidden
                        />
                      ))}
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-3">Distribution by region</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center gap-3">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: "var(--chart-2)" }} />
                        <span className="text-sm">South</span>
                        <span className="ml-auto text-sm text-muted-foreground">34%</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: "var(--chart-3)" }} />
                        <span className="text-sm">West</span>
                        <span className="ml-auto text-sm text-muted-foreground">27%</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: "var(--chart-4)" }} />
                        <span className="text-sm">North</span>
                        <span className="ml-auto text-sm text-muted-foreground">22%</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: "var(--chart-5)" }} />
                        <span className="text-sm">East</span>
                        <span className="ml-auto text-sm text-muted-foreground">17%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {enabled("vaccination-coverage") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartPie className="h-4 w-4 text-primary" />}
                    title="Vaccination Coverage"
                    description="Coverage by dose and age cohort."
                    actions={
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toast.info("Target cohorts prioritized")}
                      >
                        Prioritize
                      </Button>
                    }
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center justify-center">
                    <Donut percent={summary.vaccinatedPct} label="Fully vaccinated" ariaLabel="Fully vaccinated percentage" color="var(--chart-4)" />
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm font-medium mb-3">By dose</p>
                    <div className="space-y-2">
                      {[
                        { k: "Dose 1", v: 88, c: "var(--chart-2)" },
                        { k: "Dose 2", v: 76, c: "var(--chart-3)" },
                        { k: "Booster", v: 44, c: "var(--chart-5)" },
                      ].map((row) => (
                        <div key={row.k} className="flex items-center gap-3">
                          <div className="h-2 rounded" style={{ width: `${row.v}%`, backgroundColor: row.c }} aria-hidden />
                          <span className="text-xs min-w-0 truncate">{row.k}</span>
                          <span className="ml-auto text-xs text-muted-foreground">{row.v}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm font-medium mb-3">By age cohort</p>
                    <MiniBar
                      values={[52, 68, 74, 61, 48]}
                      ariaLabel="Vaccination by age cohorts"
                      colors={["var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"]}
                    />
                    <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                      <span>18-25</span>
                      <span>26-35</span>
                      <span>36-45</span>
                      <span>46-55</span>
                      <span>56+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {enabled("disease-trends") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartSpline className="h-4 w-4 text-primary" />}
                    title="Disease Incidence Trends"
                    description="7-day moving average by syndrome."
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {[
                    { name: "Respiratory", color: "var(--chart-1)", values: [8, 10, 12, 9, 11, 13, 14, 16, 13, 12, 15] },
                    { name: "Gastrointestinal", color: "var(--chart-3)", values: [4, 5, 5, 7, 6, 8, 7, 9, 8, 7, 8] },
                    { name: "Vector-borne", color: "var(--chart-5)", values: [2, 3, 4, 4, 5, 6, 7, 5, 6, 7, 8] },
                  ].map((s) => (
                    <div key={s.name} className="rounded-md border p-4">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">{s.name}</p>
                        <Badge variant="outline">7d avg</Badge>
                      </div>
                      <MiniSparkline values={s.values} color={s.color} ariaLabel={`${s.name} trend`} />
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {enabled("hospital-usage") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartArea className="h-4 w-4 text-primary" />}
                    title="Hospital Usage"
                    description="OPD visits, admissions, bed occupancy."
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground">OPD daily</p>
                    <MiniBar values={[40, 44, 38, 52, 60, 58, 61]} ariaLabel="OPD daily visits" colors={["var(--chart-1)"]} />
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground">Admissions</p>
                    <MiniBar values={[10, 12, 9, 13, 15, 14, 16]} ariaLabel="Daily admissions" colors={["var(--chart-3)"]} />
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground">Bed occupancy</p>
                    <Donut percent={68} label="Avg occupancy" ariaLabel="Bed occupancy average" color="var(--chart-2)" />
                  </div>
                </CardContent>
              </Card>
            )}

            {enabled("demographics") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartScatter className="h-4 w-4 text-primary" />}
                    title="Demographic Health Trends"
                    description="Health checks and risk factors across age and gender."
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-2">Screenings by age</p>
                    <MiniBar
                      values={[22, 30, 36, 28, 18]}
                      ariaLabel="Screenings by age bands"
                      colors={["var(--chart-5)"]}
                    />
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-2">Risk factor prevalence</p>
                    <div className="space-y-2">
                      {[
                        { k: "Hypertension", v: 14 },
                        { k: "Diabetes", v: 9 },
                        { k: "Anemia", v: 18 },
                        { k: "Malnutrition", v: 6 },
                      ].map((r) => (
                        <div key={r.k} className="flex items-center gap-3">
                          <div className="h-2 rounded bg-chart-4" style={{ width: `${r.v * 4}%` }} aria-hidden />
                          <span className="text-xs min-w-0 truncate">{r.k}</span>
                          <span className="ml-auto text-xs text-muted-foreground">{r.v}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="surveillance" className="space-y-4 pt-4">
            {enabled("ai-surveillance") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<Radar className="h-4 w-4 text-primary" />}
                    title="AI-powered Disease Surveillance"
                    description="Anomaly detection, spatiotemporal clustering, and early warning alerts."
                    actions={
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toast.success("Surveillance refreshed")}
                      >
                        Refresh
                      </Button>
                    }
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2 rounded-md border p-4">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm font-medium">Current alerts</p>
                      <Badge variant="destructive">High</Badge>
                    </div>
                    <div className="space-y-3">
                      {[
                        { sev: "High", text: "Dengue-like cluster detected in BLR East (p<0.01)", color: "var(--destructive)" },
                        { sev: "Medium", text: "Influenza uptick in Pune South vs. baseline", color: "var(--chart-3)" },
                        { sev: "Low", text: "Gastroenteritis above threshold in AHD North", color: "var(--chart-5)" },
                      ].map((a, i) => (
                        <div key={i} className="flex items-start gap-3 rounded-md border p-3">
                          <Radar className="h-5 w-5" style={{ color: a.color }} />
                          <div className="min-w-0">
                            <p className="font-medium truncate">{a.text}</p>
                            <p className="text-xs text-muted-foreground">Updated 5m ago</p>
                          </div>
                          <Badge variant={a.sev === "High" ? "destructive" : "secondary"} className="ml-auto">
                            {a.sev}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm font-medium mb-2">Coverage & signal</p>
                    <Donut percent={82} label="Signal quality" ariaLabel="Signal quality" color="var(--chart-1)" />
                    <div className="mt-3 text-xs text-muted-foreground">
                      Ingestion from 178 facilities in last 24h.
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {enabled("scheme-enrollment") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartColumnStacked className="h-4 w-4 text-primary" />}
                    title="Scheme Enrollment Tracking"
                    description="Enrollment progress and drop-off points."
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-2">Stages funnel</p>
                    <div className="space-y-2">
                      {[
                        { k: "Eligibility checked", v: 100 },
                        { k: "Documents submitted", v: 76 },
                        { k: "Approved", v: 59 },
                        { k: "Benefits disbursed", v: 44 },
                      ].map((row) => (
                        <div key={row.k} className="flex items-center gap-3">
                          <div className="h-3 rounded bg-chart-2" style={{ width: `${row.v}%` }} aria-hidden />
                          <span className="text-xs min-w-0 truncate">{row.k}</span>
                          <span className="ml-auto text-xs text-muted-foreground">{row.v}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-2">Recent actions</p>
                    <ScrollArea className="h-40 rounded-md border">
                      <div className="p-3 space-y-3">
                        {new Array(8).fill(0).map((_, i) => (
                          <div key={i} className="flex items-start gap-3">
                            <ChartBarBig className="h-4 w-4 text-primary mt-0.5" />
                            <div className="min-w-0">
                              <p className="text-sm truncate">
                                {i + 1}. Enrollment update processed
                              </p>
                              <p className="text-xs text-muted-foreground">By System · {15 - i}m ago</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="compliance" className="space-y-4 pt-4">
            {enabled("employer-compliance") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartBarBig className="h-4 w-4 text-primary" />}
                    title="Employer Compliance Monitoring"
                    description="Vaccination mandates, health checks, and safety trainings."
                  />
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="rounded-md border p-4">
                      <p className="text-sm text-muted-foreground">Compliant employers</p>
                      <Donut percent={72} label="Compliant" ariaLabel="Compliance percent" color="var(--chart-3)" />
                    </div>
                    <div className="rounded-md border p-4">
                      <p className="text-sm text-muted-foreground">Avg training completion</p>
                      <MiniBar values={[30, 44, 51, 60, 62, 67]} ariaLabel="Training completion" colors={["var(--chart-4)"]} />
                    </div>
                    <div className="rounded-md border p-4">
                      <p className="text-sm text-muted-foreground">Pending actions</p>
                      <div className="space-y-2">
                        {[
                          "Upload safety audit",
                          "Submit PPE inventory",
                          "Schedule health camp",
                        ].map((task, i) => (
                          <div key={task} className="flex items-center gap-2">
                            <Checkbox id={`task-${i}`} />
                            <Label htmlFor={`task-${i}`} className="text-sm min-w-0 truncate cursor-pointer">
                              {task}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="rounded-md border">
                    <div className="p-4 border-b flex items-center justify-between">
                      <p className="font-medium">Employers</p>
                      <Button size="sm" variant="outline" onClick={handleExportCSV}>
                        Export CSV
                      </Button>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-12 gap-2 text-sm font-medium">
                        <div className="col-span-5">Name</div>
                        <div className="col-span-3">Workers</div>
                        <div className="col-span-2">Compliance</div>
                        <div className="col-span-2 text-right">Action</div>
                      </div>
                      <Separator className="my-3" />
                      <div className="space-y-3">
                        {[
                          { n: "Shree Constructions", w: 820, c: 76 },
                          { n: "MetroTextiles Ltd.", w: 1450, c: 69 },
                          { n: "Rapid Logistics", w: 560, c: 83 },
                          { n: "Sunrise Foods", w: 390, c: 58 },
                        ].map((row) => (
                          <div key={row.n} className="grid grid-cols-12 gap-2 items-center">
                            <div className="col-span-5 min-w-0 truncate">{row.n}</div>
                            <div className="col-span-3">{row.w}</div>
                            <div className="col-span-2">
                              <Badge variant={row.c >= 75 ? "secondary" : "outline"}>
                                {row.c}%
                              </Badge>
                            </div>
                            <div className="col-span-2 text-right">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => toast.info("Compliance detail opened")}
                              >
                                View
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {enabled("health-score") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<ChartArea className="h-4 w-4 text-primary" />}
                    title="Health Score Distribution"
                    description="Distribution across low, medium, and high risk segments."
                  />
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col sm:flex-row items-center gap-6">
                    <div className="flex-1 w-full min-w-0">
                      <div className="h-4 w-full rounded bg-muted overflow-hidden">
                        <div className="h-full" style={{ width: "28%", backgroundColor: "var(--destructive)" }} aria-hidden />
                        <div className="h-full" style={{ width: "42%", backgroundColor: "var(--chart-3)" }} aria-hidden />
                        <div className="h-full" style={{ width: "30%", backgroundColor: "var(--chart-2)" }} aria-hidden />
                      </div>
                      <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                        <span>Low</span>
                        <span>Medium</span>
                        <span>High</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="destructive">Low 28%</Badge>
                      <Badge className="bg-chart-3 text-white">Med 42%</Badge>
                      <Badge className="bg-chart-2 text-primary">High 30%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {enabled("qr-usage") && (
              <Card className="bg-card">
                <CardHeader className="pb-3">
                  <SectionHeader
                    icon={<SquareActivity className="h-4 w-4 text-primary" />}
                    title="QR Code Usage"
                    description="Scans for health record access across facilities."
                  />
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-2">Daily scans (7d)</p>
                    <MiniBar
                      values={[18, 22, 26, 24, 30, 34, 40]}
                      ariaLabel="Daily QR scans"
                      colors={["var(--chart-5)"]}
                    />
                  </div>
                  <div className="rounded-md border p-4">
                    <p className="text-sm text-muted-foreground mb-2">Top facilities</p>
                    <div className="space-y-2">
                      {[
                        { n: "City General", v: 320 },
                        { n: "Metro Care", v: 260 },
                        { n: "Sunrise Health", v: 210 },
                      ].map((f) => (
                        <div key={f.n} className="flex items-center gap-3">
                          <div className="h-2 rounded bg-chart-5" style={{ width: `${Math.min(100, (f.v / 320) * 100)}%` }} aria-hidden />
                          <span className="text-xs min-w-0 truncate">{f.n}</span>
                          <span className="ml-auto text-xs text-muted-foreground">{f.v}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="gdpr" className="space-y-4 pt-4">
            <Card className="bg-card">
              <CardHeader className="pb-3">
                <SectionHeader
                  icon={<ChartNoAxesCombined className="h-4 w-4 text-primary" />}
                  title="GDPR & Data Protection"
                  description="Control data retention, subject access exports, and anonymization."
                />
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-md border p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Anonymize analytics</p>
                      <p className="text-sm text-muted-foreground">
                        Strip identifiers from charts and exports.
                      </p>
                    </div>
                    <Switch checked={onlyAnonymized} onCheckedChange={handleAnonymizeToggle} />
                  </div>
                  <div className="space-y-2">
                    <Label>Data retention</Label>
                    <Select
                      onValueChange={(v) => toast.message("Retention updated", { description: `${v} months` })}
                    >
                      <SelectTrigger aria-label="Data retention">
                        <SelectValue placeholder="Select months" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="6">6 months</SelectItem>
                        <SelectItem value="12">12 months</SelectItem>
                        <SelectItem value="24">24 months</SelectItem>
                        <SelectItem value="36">36 months</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Applies to raw event logs and identifiers.
                    </p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Consent for analytics</p>
                      <p className="text-sm text-muted-foreground">
                        Respect consent for non-essential processing.
                      </p>
                    </div>
                    <Switch
                      checked={gdprConsent}
                      onCheckedChange={(c) => {
                        setGdprConsent(c);
                        toast.info(c ? "Analytics consent ON" : "Analytics consent OFF");
                      }}
                    />
                  </div>
                </div>
                <div className="rounded-md border p-4 space-y-3">
                  <p className="font-medium">Data subject tools</p>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      onClick={() => toast.success("Data export prepared", { description: "You will receive a CSV shortly." })}
                    >
                      <FileChartLine className="mr-2 h-4 w-4" />
                      Export personal data
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={() => toast.warning("Deletion request received")}
                    >
                      Request deletion
                    </Button>
                  </div>
                  <div className="rounded-md border p-3 bg-secondary">
                    <p className="text-sm">
                      This dashboard adheres to minimization and purpose limitation. Contact DPO for escalations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-4 pt-4">
            <Card className="bg-card">
              <CardHeader className="pb-3">
                <SectionHeader
                  icon={<Logs className="h-4 w-4 text-primary" />}
                  title="Audit Logs"
                  description="Immutable logs of data access and admin actions."
                />
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Search logs (user, action, resource)"
                      className="w-64 max-w-full"
                      onChange={() => {}}
                      aria-label="Search audit logs"
                    />
                    <Select onValueChange={() => {}}>
                      <SelectTrigger aria-label="Severity filter">
                        <SelectValue placeholder="All severities" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ALL">All</SelectItem>
                        <SelectItem value="INFO">Info</SelectItem>
                        <SelectItem value="WARN">Warn</SelectItem>
                        <SelectItem value="ERROR">Error</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button variant="outline" onClick={handleExportCSV}>
                    Export logs
                  </Button>
                </div>
                <div className="rounded-md border">
                  <div className="grid grid-cols-12 gap-2 px-4 py-2 text-sm font-medium">
                    <div className="col-span-3">Timestamp</div>
                    <div className="col-span-2">User</div>
                    <div className="col-span-2">Action</div>
                    <div className="col-span-3">Resource</div>
                    <div className="col-span-2">Status</div>
                  </div>
                  <Separator />
                  <ScrollArea className="h-64">
                    <div className="divide-y">
                      {[
                        { t: "2025-09-14 10:12", u: "admin@state.gov", a: "EXPORT", r: "vaccination.csv", s: "INFO" },
                        { t: "2025-09-14 09:40", u: "officer@district.gov", a: "VIEW", r: "alerts", s: "INFO" },
                        { t: "2025-09-14 09:05", u: "auditor@state.gov", a: "ACCESS", r: "audit_logs", s: "WARN" },
                        { t: "2025-09-14 08:58", u: "hospital-admin@metro", a: "UPDATE", r: "facility_profile", s: "INFO" },
                        { t: "2025-09-14 08:23", u: "system", a: "ANONYMIZE", r: "export_job_1287", s: "INFO" },
                      ].map((row, i) => (
                        <div key={i} className="grid grid-cols-12 gap-2 px-4 py-2 text-sm">
                          <div className="col-span-3">{row.t}</div>
                          <div className="col-span-2 min-w-0 truncate">{row.u}</div>
                          <div className="col-span-2">{row.a}</div>
                          <div className="col-span-3 min-w-0 break-words">{row.r}</div>
                          <div className="col-span-2">
                            <Badge variant={row.s === "ERROR" ? "destructive" : row.s === "WARN" ? "outline" : "secondary"}>
                              {row.s}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}